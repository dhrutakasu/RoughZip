package com.fancytext.nicnamegenerator.namemerger.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;


import com.fancytext.nicnamegenerator.namemerger.BuildConfig;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.AllManager;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.admob.PageChange;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityStartBinding;

public class StartActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityStartBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        BigNat.getInstance(this).show();
        binding.start.setOnClickListener(this);
        binding.privacyPolicy.setOnClickListener(this);
        binding.share.setOnClickListener(this);
        binding.rate   .setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
       switch (v.getId()){
           case R.id.start:
               PageChange.getInstance(this,()->{
                   startActivity(new Intent(StartActivity.this,HomeActivity.class));
               }).show();

               break;
           case R.id.share:
               try {
                   Intent shareIntent = new Intent(Intent.ACTION_SEND);
                   shareIntent.setType("text/plain");
                   shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Install this app");
                   String shareMessage = "\nLet me recommend you this application\n\n";
                   shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                   shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                   startActivity(Intent.createChooser(shareIntent, "choose one"));
               } catch (Exception e) {
                   //e.toString();
               }
               break;
           case R.id.privacyPolicy:
               AllManager.gotoTerms(StartActivity.this);
               break;
           case R.id.rate:
               try {
                   startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
               } catch (ActivityNotFoundException e) {
                   startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
               }
               break;
       }
    }
}