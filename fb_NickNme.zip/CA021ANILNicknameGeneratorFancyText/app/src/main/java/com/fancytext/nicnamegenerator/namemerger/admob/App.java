package com.fancytext.nicnamegenerator.namemerger.admob;

import com.google.gson.annotations.SerializedName;

public class App {
    @SerializedName("app_id")
    public String a_id;
    @SerializedName("app_package")
    public String a_package;
    @SerializedName("url")
    public String url;
    @SerializedName("policy_link")
    public String policy;
    @SerializedName("version")
    public String version;
    @SerializedName("version_code")
    public int version_code;
    @SerializedName("ad_priority")
    public int priority;
    @SerializedName("is_force_update")
    public boolean is_force;
    @SerializedName("is_ad_on")
    public boolean is_on;
    @SerializedName("is_splash_app_open")
    public boolean is_splash_open;
    @SerializedName("is_extra_screen")
    public boolean is_extra;
    @SerializedName("is_back_ad_on")
    public boolean is_back_on;
    @SerializedName("is_mini_native")
    public boolean is_mini;
    @SerializedName("is_large_native")
    public boolean is_large;
    @SerializedName("is_reward")
    public boolean is_reward;
    @SerializedName("is_exit_inter")
    public boolean is_exit;
    @SerializedName("is_in_app_custom")
    public boolean is_in_custom;
    @SerializedName("is_custom_ad_on")
    public boolean is_custom_on;
    @SerializedName("is_god_mode_on")
    public boolean is_god_on;
    @SerializedName("is_god_mode_on_forcefully")
    public boolean is_forcefully;
    @SerializedName("is_god_mode_callback_on")
    public boolean is_god_callback_on;
    @SerializedName("god_mode_url")
    public String god_url;
    @SerializedName("god_mode_carrier_id")
    public String god_mode_carrier_id;
    @SerializedName("god_mode_country")
    public String god_country;
    @SerializedName("god_mode_ref")
    public String god_ref;
    @SerializedName("native_bg_color")
    public String n_bg_color;
    @SerializedName("native_text_color")
    public String n_text_color;
    @SerializedName("native_btn_color")
    public String n_btn_color;
    @SerializedName("inter_count")
    public int int_count;
    @SerializedName("back_inter_count")
    public int back_in_count;
    @SerializedName("ad_refresh_timer")
    public int refresh_timer;
    @SerializedName("inter_loader_seconds")
    public int int_loader_sec;
    @SerializedName("admob_banner_id")
    public String g_banner_id;
    @SerializedName("admob_native_id")
    public String g_native_id;
    @SerializedName("admob_inter_id")
    public String g_inter_id;
    @SerializedName("admob_reward_id")
    public String g_reward_id;
    @SerializedName("admob_app_open_id")
    public String g_app_open_id;
    @SerializedName("fb_banner_id")
    public String f_banner_id;
    @SerializedName("fb_native_id")
    public String f_native_id;
    @SerializedName("fb_inter_id")
    public String f_inter_id;
    @SerializedName("fb_reward_id")
    public String f_reward_id;
    @SerializedName("q_url")
    public String q_url;
}