package com.fancytext.nicnamegenerator.namemerger.admob;

import static android.view.View.GONE;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.preference.PowerPreference;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class BigNat {

    private static final String TAG = "BigNat";
    private static ArrayList<NativeAd> gNativeAds = new ArrayList<>();
    private static ArrayList<com.facebook.ads.NativeAd> fNativeAds = new ArrayList<>();
    Activity context;

    public static final int G = 0;
    public static final int F = 1;

    int adPriority = G;
    String gNativeAdId = "";
    String fNativeAdId = "";
    int refreshTime = 0;
    boolean isOn = false;
    boolean isLargeOn = false;
    public String nativeText = "#FF363636";
    public String nativeBtn = "#FF363636";
    public boolean isCustomOn = false;
    public boolean isInCustom = false;


    public static BigNat getInstance(Activity context) {
        return new BigNat(context);
    }

    public BigNat(Activity context) {
        this.context = context;
        adPriority = PowerPreference.getDefaultFile().getInt( AllManager.PRIORITY, G);
        gNativeAdId = PowerPreference.getDefaultFile().getString( AllManager.G_NATIVE_ID);
        fNativeAdId = PowerPreference.getDefaultFile().getString( AllManager.F_NATIVE_ID);
        refreshTime = PowerPreference.getDefaultFile().getInt( AllManager.REFRESH_TIMER, refreshTime);
        isOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_ON, isOn);
        isLargeOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_LARGE, isLargeOn);
        nativeText = PowerPreference.getDefaultFile().getString( AllManager.N_TEXT_COLOR, nativeText);
        nativeBtn = PowerPreference.getDefaultFile().getString( AllManager.N_BTN_COLOR, nativeBtn);
        isCustomOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_CUSTOM_ON, isCustomOn);
        isInCustom = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_IN_CUSTOM, isInCustom);
    }


    // Call This Method Once In Splash Screen
    public void load() {
        Log.e(TAG, "BigNat-> load: ");
        // Return Direct While Ad is Off
        if (!isOn || !isLargeOn) {
            return;
        }

        switch (adPriority) {
            case G: {
                loadGoogleNativeAd();
                break;
            }
            case F: {
                loadFBNativeAd();
            }
        }
    }


    private void loadGoogleNativeAd() {
        Log.e(TAG, "loadGoogleNativeAd: " + gNativeAdId);
        AdLoader.Builder builder = new AdLoader.Builder(context, gNativeAdId);
        builder.forNativeAd(natives -> {
            gNativeAds.clear();
            gNativeAds.add(natives);
        });

        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(LoadAdError errorCode) {
                Log.e(TAG, "loadNativeAds failed" + errorCode.toString());
                gNativeAds.clear();
                if (adPriority == G) {
                    loadFBNativeAd();
                }
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private void loadFBNativeAd() {
        Log.e(TAG, "loadFBNativeAd: " + fNativeAdId);
        final com.facebook.ads.NativeAd fbnativeAd = new com.facebook.ads.NativeAd(context, fNativeAdId);

        fbnativeAd.loadAd(fbnativeAd.buildLoadAdConfig().withAdListener(new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e(TAG, "loadFBNativeAd->onError: " + adError.getErrorMessage());

                if (adPriority == F) {
                    loadGoogleNativeAd();
                }
            }

            @Override
            public void onAdLoaded(Ad ad) {
                fNativeAds.clear();
                fNativeAds.add((com.facebook.ads.NativeAd) ad);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        }).build());
    }

    //region Show Native Ads
    FrameLayout lytNativeAd;
    TextView tvAdSpace;

    public void show() {
        lytNativeAd = context.findViewById( R.id.native_ad);
        tvAdSpace = context.findViewById( R.id.ad_space);

        Log.e( TAG, "show: " + lytNativeAd  );
        Log.e( TAG, "show: " + tvAdSpace  );

        // Return Direct While Ad is Off
        if (!isOn || !isLargeOn) {
            lytNativeAd.setVisibility(GONE);
            tvAdSpace.setVisibility(GONE);
            return;
        }

        switch (adPriority) {
            case G: {
                showGoogleNative();
                break;
            }
            case F: {
                showFBNative();
                break;
            }
        }
    }

    private void showGoogleNative() {
        if (!gNativeAds.isEmpty()) {
            LinearLayout adView = (LinearLayout) context.getLayoutInflater().inflate(R.layout.ads_google_normal, null);

            TextView ad_headline = adView.findViewById(R.id.ad_headline);
            TextView ad_body = adView.findViewById(R.id.ad_body);
            TextView ad_call_to_action = adView.findViewById(R.id.ad_call_to_action);
            ad_call_to_action.setSelected(true);

            ad_body.setTextColor(Color.parseColor(nativeText));
            ad_headline.setTextColor(Color.parseColor(nativeText));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ad_call_to_action.getBackground().setTint(Color.parseColor(nativeBtn));
            }

            NativeAd lovalNative = gNativeAds.get(0);

            populateUnifiedNativeAdView(lovalNative, adView.findViewById(R.id.uadview));

            lytNativeAd.removeAllViews();
            lytNativeAd.addView(adView);


            tvAdSpace.setVisibility(View.GONE);
            lytNativeAd.setVisibility(View.VISIBLE);

            // Load native with refresh
            new Handler().postDelayed(this::load, refreshTime * 1000L);
        } else {
            if (adPriority == G) {
                showFBNative();
            } else {
                new Handler().postDelayed(this::load, refreshTime * 1000L);
                showCustomAd();
            }

        }
    }


    private void showFBNative() {
        if (!fNativeAds.isEmpty()) {
            LinearLayout adView = (LinearLayout) context.getLayoutInflater().inflate(R.layout.ads_facebook_normal, null);

            TextView ad_headline = adView.findViewById(R.id.ad_headline);
            TextView ad_body = adView.findViewById(R.id.ad_body);
            TextView ad_call_to_action = adView.findViewById(R.id.ad_call_to_action);
            ad_call_to_action.setSelected(true);

            ad_body.setTextColor(Color.parseColor(nativeText));
            ad_headline.setTextColor(Color.parseColor(nativeText));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ad_call_to_action.getBackground().setTint(Color.parseColor(nativeBtn));
            }

            com.facebook.ads.NativeAd lovalNative = fNativeAds.get(0);

            inflateAd(lovalNative, adView.findViewById(R.id.uadview));

            lytNativeAd.removeAllViews();
            lytNativeAd.addView(adView);

            tvAdSpace.setVisibility(View.GONE);
            lytNativeAd.setVisibility(View.VISIBLE);

            new Handler().postDelayed(this::load, refreshTime * 1000L);
        } else {
            if (adPriority == F) {
                showGoogleNative();
            } else {
                new Handler().postDelayed(this::load, refreshTime * 1000L);
                showCustomAd();
            }
        }
    }


    public void populateUnifiedNativeAdView(NativeAd nativeAd, NativeAdView adView) {

        if (adView.findViewById(R.id.ad_media) != null) {
            MediaView mediaView = adView.findViewById(R.id.ad_media);
            mediaView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
            adView.setMediaView(mediaView);

        }
        if (adView.findViewById(R.id.ad_headline) != null)
            adView.setHeadlineView(adView.findViewById(R.id.ad_headline));

        if (adView.findViewById(R.id.ad_body) != null)
            adView.setBodyView(adView.findViewById(R.id.ad_body));

        if (adView.findViewById(R.id.ad_call_to_action) != null)
            adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));

        if (adView.findViewById(R.id.ad_app_icon) != null)
            adView.setIconView(adView.findViewById(R.id.ad_app_icon));

        if (nativeAd.getStarRating() == null) {
            if (adView.getStarRatingView() != null)
                Objects.requireNonNull(adView.getStarRatingView()).setVisibility(View.GONE);
        } else {
            if (adView.getStarRatingView() != null) {
                Objects.requireNonNull(adView.getStarRatingView()).setVisibility(View.VISIBLE);
                ((RatingBar) adView.getStarRatingView()).setRating(Float.parseFloat(String.valueOf(nativeAd.getStarRating())));
            }
        }

        if (nativeAd.getHeadline() == null) {
            if (adView.getHeadlineView() != null)
                Objects.requireNonNull(adView.getHeadlineView()).setVisibility(View.GONE);
        } else {
            if (adView.getHeadlineView() != null) {
                Objects.requireNonNull(adView.getHeadlineView()).setVisibility(View.VISIBLE);
                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
            }
        }

        if (nativeAd.getBody() == null) {
            if (adView.getBodyView() != null)
                Objects.requireNonNull(adView.getBodyView()).setVisibility(View.GONE);
        } else {
            if (adView.getBodyView() != null) {
                Objects.requireNonNull(adView.getBodyView()).setVisibility(View.VISIBLE);
                ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
            }
        }

        if (nativeAd.getCallToAction() == null) {
            if (adView.getCallToActionView() != null)
                Objects.requireNonNull(adView.getCallToActionView()).setVisibility(View.INVISIBLE);
        } else {
            if (adView.getCallToActionView() != null) {
                Objects.requireNonNull(adView.getCallToActionView()).setVisibility(View.VISIBLE);
                ((TextView) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
            }
        }

        if (nativeAd.getIcon() == null) {
            if (adView.getIconView() != null)
                Objects.requireNonNull(adView.getIconView()).setVisibility(View.GONE);
        } else {
            if (adView.getIconView() != null) {
                ((ImageView) Objects.requireNonNull(adView.getIconView())).setImageDrawable(nativeAd.getIcon().getDrawable());
                adView.getIconView().setVisibility(View.VISIBLE);
            }
        }

        adView.setNativeAd(nativeAd);
    }

    public void inflateAd(com.facebook.ads.NativeAd nativeAd, NativeAdLayout adView) {

        nativeAd.unregisterView();

        com.facebook.ads.MediaView nativeAdIcon = adView.findViewById(R.id.ad_app_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.ad_headline);
        com.facebook.ads.MediaView nativeAdMedia = adView.findViewById(R.id.ad_media);
        TextView nativeAdBody = adView.findViewById(R.id.ad_body);
        TextView nativeAdCallToAction = adView.findViewById(R.id.ad_call_to_action);
        nativeAdCallToAction.setSelected(true);

        if (nativeAdTitle != null) {
            if (nativeAd.getAdHeadline() == null) {
                nativeAdTitle.setVisibility(View.GONE);
            } else {
                nativeAdTitle.setVisibility(View.VISIBLE);
                nativeAdTitle.setText(nativeAd.getAdHeadline());
            }
        }

        if (nativeAdBody != null) {
            if (nativeAd.getAdBodyText() == null) {
                nativeAdBody.setVisibility(View.GONE);
            } else {
                nativeAdBody.setVisibility(View.VISIBLE);
                nativeAdBody.setText(nativeAd.getAdBodyText());
            }
        }

        if (nativeAdCallToAction != null) {
            if (nativeAd.getAdCallToAction() == null) {
                nativeAdCallToAction.setVisibility(View.INVISIBLE);
            } else {
                nativeAdCallToAction.setVisibility(View.VISIBLE);
                nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
            }
        }
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);

        nativeAd.registerViewForInteraction(adView, nativeAdMedia, nativeAdIcon, clickableViews);

    }

    private void showCustomAd() {
        //TODO manage Custom Ads
        if (!isCustomOn) {
            lytNativeAd.setVisibility(View.GONE);
            tvAdSpace.setVisibility(View.GONE);
            return;
        }


        View view = LayoutInflater.from(context).inflate(R.layout.ads_custom_normal, lytNativeAd, false);

        LinearLayout cvMain = view.findViewById(R.id.cvMain);
        TextView ad_call_to_action = view.findViewById(R.id.ad_call_to_action);
        TextView ad_headline = view.findViewById(R.id.ad_headline);
        TextView ad_body = view.findViewById(R.id.ad_body);
        ImageView ad_app_icon = view.findViewById(R.id.ad_app_icon);
        ImageView ad_media = view.findViewById(R.id.ad_media);

        ad_call_to_action.setSelected(true);

        if (isInCustom) {
            if (PowerPreference.getDefaultFile().getInt(AllManager.ADS_NORMAL, 0) >= 5) {
                PowerPreference.getDefaultFile().putInt(AllManager.ADS_NORMAL, 0);
                showCustomAd();
                return;
            }
            Log.e(TAG, "showCustomAd: ");
            ad_call_to_action.setText("Play Now");
            cvMain.setOnClickListener(v -> AllManager.gotoAds(context, PowerPreference.getDefaultFile().getString(AllManager.Q_URL)));

            ad_headline.setText("Play & Win Coins");
            ad_body.setText("Win 5,00,000 Coins & More");

            ad_body.setTextColor(Color.parseColor(nativeText));
            ad_headline.setTextColor(Color.parseColor(nativeText));
            ad_call_to_action.getBackground().setTint(Color.parseColor(nativeBtn));


            Glide.with(context).load(AllManager.adsQurekaGifInters[PowerPreference.getDefaultFile().getInt(AllManager.ADS_NORMAL, 0)]).centerCrop().into(ad_app_icon);
            Glide.with(context).load(AllManager.adsQurekaInters[PowerPreference.getDefaultFile().getInt(AllManager.ADS_NORMAL, 0)]).centerCrop().into(ad_media);

            int top = PowerPreference.getDefaultFile().getInt(AllManager.ADS_NORMAL, 0) + 1;
            PowerPreference.getDefaultFile().putInt(AllManager.ADS_NORMAL, top == 5 ? 0 : top);


        } else {
            CustomAd customAd = AllManager.getInstance(context).getCustomAd(AllManager.AD_TYPE_NATIVE);
            ad_call_to_action.setText(customAd.btn_text);
            cvMain.setOnClickListener(v -> AllManager.gotoAds(context, customAd.url));

            ad_headline.setText(customAd.title);
            ad_body.setText(customAd.description);

            ad_headline.setTextColor(Color.parseColor(customAd.text_color));
            ad_body.setTextColor(Color.parseColor(customAd.text_color));
            ad_call_to_action.setTextColor(Color.parseColor(customAd.btn_text_color));
            cvMain.setBackgroundColor(Color.parseColor(customAd.bg_color));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                ad_call_to_action.getBackground().setTint(Color.parseColor(customAd.btn_color));
            }
            ad_call_to_action.setTextColor(Color.parseColor(customAd.btn_text_color));

            Glide.with(context).load(AllManager.BASE_URL + customAd.logo).centerCrop().into(ad_app_icon);
            Glide.with(context).load(AllManager.BASE_URL + customAd.media_image).centerCrop().into(ad_media);
        }

        lytNativeAd.removeAllViews();
        lytNativeAd.addView(view);

        tvAdSpace.setVisibility(View.GONE);
        lytNativeAd.setVisibility(View.VISIBLE);


    }


    public void showListNativeAds(FrameLayout nativeAd, TextView adsSpace) {
        lytNativeAd = nativeAd;
        tvAdSpace = adsSpace;

        // Return Direct While Ad is Off
        if (!isOn || !isLargeOn) {
            lytNativeAd.setVisibility(GONE);
            tvAdSpace.setVisibility(GONE);
            return;
        }

        switch (adPriority) {
            case G: {
                showGoogleNative();
                break;
            }
            case F: {
                showFBNative();
                break;
            }
        }

    }
}
