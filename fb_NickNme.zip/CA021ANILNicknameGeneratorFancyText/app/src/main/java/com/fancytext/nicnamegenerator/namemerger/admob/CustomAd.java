package com.fancytext.nicnamegenerator.namemerger.admob;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CustomAd implements Serializable {
    @SerializedName("title")
    public String title;
    @SerializedName("description")
    public String description;
    @SerializedName("btn_color")
    public String btn_color;
    @SerializedName("btn_text")
    public String btn_text;
    @SerializedName("btn_text_color")
    public String btn_text_color;
    @SerializedName("media_image")
    public String media_image;
    @SerializedName("logo")
    public String logo;
    @SerializedName("url")
    public String url;
    @SerializedName("type")
    public int type;
    @SerializedName("bg_color")
    public String bg_color;
    @SerializedName("text_color")
    public String text_color;
}