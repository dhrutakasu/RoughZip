package com.fancytext.nicnamegenerator.namemerger.admob;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.fancytext.nicnamegenerator.namemerger.BuildConfig;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.preference.PowerPreference;
import com.preference.Preference;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class AllManager {
    static {
        System.loadLibrary("hello-jni");
    }

    public static final String TAG = "AllManager";

    public static native String BaseUrl();

    public static native String BackupBaseUrl();

    public static final String BASE_URL = BaseUrl();
    public static final String BACKUP_BASE_URL = BackupBaseUrl();
    public static final String PRIMARY_SERVER_URL = BASE_URL + "/v1/app/get_application_data";
    public static final String BACKUP_SERVER_URL = BACKUP_BASE_URL + "/v1/app/get_application_data";
    public static final String SEND_NOTIFICATION = BASE_URL + "/v1/app/send_notification";


    public static final String AD_RESPONSE = "adResponse";
    Map<String, String> appData = new HashMap<>();


    public static final int AD_TYPE_INTER = 0;
    public static final int AD_TYPE_NATIVE = 1;
    public static final int AD_APP_OPEN = 3;

    public static String ADS_NORMAL = "ADS_NORMAL";
    public static Integer[] adsQurekaInters = new Integer[]{R.drawable.qureka_inter1, R.drawable.qureka_inter2, R.drawable.qureka_inter3, R.drawable.qureka_inter4, R.drawable.qureka_inter5};
    public static Integer[] adsQurekaGifInters = new Integer[]{R.drawable.qureka_round1, R.drawable.qureka_round2, R.drawable.qureka_round3, R.drawable.qureka_round4, R.drawable.qureka_round5};


    Activity activity;
    Preference preference;
    Data adResponse;
    public boolean isNewUser;

    public AllManager(Activity activity) {
        this.activity = activity;
        preference = PowerPreference.getDefaultFile();
        adResponse = preference.getObject(AD_RESPONSE, Data.class, null);
    }

    public static AllManager getInstance(Activity activity) {
        return new AllManager(activity);
    }


    public CustomAd getCustomAd(int adType) {
        Type type = new TypeToken<ArrayList<CustomAd>>() {
        }.getType();
        ArrayList<CustomAd> customAds = new Gson().fromJson(PowerPreference.getDefaultFile().getString( AllManager.CUSTOM_ADS, new Gson().toJson(new ArrayList<CustomAd>())), type);
        ArrayList<CustomAd> tempCustomAds = new ArrayList<>();
        for (CustomAd customAd : customAds) {
            if (customAd.type == adType) {
                tempCustomAds.add(customAd);
            }
        }

        return tempCustomAds.get(new Random().nextInt(tempCustomAds.size()));
    }


    private void setAppData() {
        SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
        boolean isRepeatedUser = false;
        boolean isExistedUser = false;
        isNewUser = false;


        if (!preference.getString(USER_VISIT_DATE).equals("")) {
            if (preference.getString(USER_VISIT_DATE).equals(formater.format(new Date()))) {
                isRepeatedUser = true;
            } else {
                isExistedUser = true;
            }
        } else {
            isNewUser = true;
        }

        appData.put("app_package", BuildConfig.APPLICATION_ID);
//        appData.put("app_package", "com.example.app");
        appData.put("date", formater.format(new Date()));
        appData.put("is_new_user", isNewUser ? "1" : "0");
        appData.put("is_exist_user", isExistedUser ? "1" : "0");
        appData.put("is_repeat_user", isRepeatedUser ? "1" : "0");
        appData.put("is_organic_user", "1");

        preference.setString(USER_VISIT_DATE, formater.format(new Date()));
    }

    public void getAdData(ResponseListener listener) {
        setAppData();

        callPrimaryServerForAdData(listener);

    }

    private void callPrimaryServerForAdData(ResponseListener listener) {
        RequestQueue queue = Volley.newRequestQueue(activity);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, PRIMARY_SERVER_URL, response -> {
            if (response != null) {
                Log.e(TAG, "callPrimaryServerForAdData response: " + response);
                Data data = new Gson().fromJson(response, Data.class);
                if (data != null && !data.error) {
                    listener.onResponse(data);
                } else {
                    callBackServerForAdData(listener);
                }
            } else {
                callBackServerForAdData(listener);
            }

        }, error -> {
            callBackServerForAdData(listener);
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() {
                return appData;
            }
        };
        stringRequest.setShouldCache(false);
        queue.add(stringRequest);
    }

    public static void getFirstNotification(Activity activity,Map<String,String> data){
        RequestQueue queue = Volley.newRequestQueue(activity);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, SEND_NOTIFICATION, response -> {
            Log.e(TAG, "getFirstNotification: " + response );

        }, error -> {
            Log.e(TAG, "getFirstNotification: " + error.toString());
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() {
                return data;
            }
        };
        stringRequest.setShouldCache(false);
        queue.add(stringRequest);
    }

    private void callBackServerForAdData(ResponseListener listener) {
        RequestQueue queue = Volley.newRequestQueue(activity);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, BACKUP_SERVER_URL, response -> {
            Data data = new Gson().fromJson(response, Data.class);
            listener.onResponse(data);
        }, listener::onFailure) {
            @Nullable
            @Override
            protected Map<String, String> getParams() {
                return appData;
            }
        };
        stringRequest.setShouldCache(false);
        queue.add(stringRequest);
    }




    public static String USER_VISIT_DATE = "user_visit_date";


    public static final String A_ID = "a_id";
    public static final String A_PACKAGE = "a_package";
    public static final String A_URL = "url";
    public static final String POLICY = "policy_link";
    public static final String A_VERSION = "version";
    public static final String A_VERSION_CODE = "version_code";
    public static final String PRIORITY = "priority";
    public static final String IS_FORCE = "is_force";
    public static final String IS_ON = "is_on";
    public static final String IS_SPLASH_OPEN = "is_splash_open";
    public static final String IS_EXTRA = "is_extra";
    public static final String IS_BACK_IN_ON = "is_back_inr_on";
    public static final String REFRESH_TIMER = "refresh_timer";
    public static final String IS_MINI = "is_minie";
    public static final String IS_LARGE = "is_large";
    public static final String IS_REWARD = "is_reward";
    public static final String IS_EXIT = "is_exit";
    public static final String IS_IN_CUSTOM = "is_in_custom";
    public static final String IS_CUSTOM_ON = "is_custom_on";
    public static final String IS_GOD_ON = "is_god_on";
    public static final String IS_GOD_ON_FORCEFULLY = "is_god_on_forcefully";
    public static final String IS_GOD_CALLBACK_ON = "is_god_callback_on";
    public static final String GOD_URL = "god_url";
    public static final String GOD_COUNTRY = "god_country";
    public static final String GOD_REF = "god_ref";
    public static final String N_BG_COLOR = "n_bg_color";
    public static final String N_TEXT_COLOR = "n_text_color";
    public static final String N_BTN_COLOR = "n_btn_color";
    public static final String INT_COUNT = "int_count";
    public static final String BACK_IN_COUNT = "back_in_count";
    public static final String INT_LOADER_SEC = "int_loader_secs";
    public static final String G_BANNER_ID = "g_banner_id";
    public static final String G_NATIVE_ID = "g_native_id";
    public static final String G_INTER_ID = "g_inter_id";
    public static final String G_REWARD_ID = "g_reward_id";
    public static final String G_APP_OPEN_ID = "g_app_open_id";
    public static final String F_BANNER_ID = "f_banner_id";
    public static final String F_NATIVE_ID = "f_native_id";
    public static final String F_INTER_ID = "f_inter_id";
    public static final String F_REWARD_ID = "f_reward_id";
    public static final String Q_URL = "q_url";
    public static final String CUSTOM_ADS = "custom_ads";
    public static final String IS_NOTIFIED = "is_notified";


    public void setAdData(Data data) {
        preference.setString(A_ID, data.app.a_id);
        preference.setString(A_PACKAGE, data.app.a_package);
        preference.setString(A_URL, data.app.url);
        preference.setString(POLICY, data.app.policy);
        preference.setString(A_VERSION, data.app.version);
        preference.setInt(A_VERSION_CODE, data.app.version_code);
        preference.setInt(PRIORITY, data.app.priority);
        preference.setBoolean(IS_FORCE, data.app.is_force);
        preference.setBoolean(IS_ON, data.app.is_on);
        preference.setBoolean(IS_SPLASH_OPEN, data.app.is_splash_open);
        preference.setBoolean(IS_EXTRA, data.app.is_extra);
        preference.setBoolean(IS_BACK_IN_ON, data.app.is_back_on);
        preference.setBoolean(IS_MINI, data.app.is_mini);
        preference.setBoolean(IS_LARGE, data.app.is_large);
        preference.setBoolean(IS_REWARD, data.app.is_reward);
        preference.setBoolean(IS_REWARD, data.app.is_reward);
        preference.setBoolean(IS_EXIT, data.app.is_exit);
        preference.setBoolean(IS_IN_CUSTOM, data.app.is_in_custom);
        preference.setBoolean(IS_CUSTOM_ON, data.app.is_custom_on);
        preference.setBoolean(IS_GOD_ON, data.app.is_god_on);
        preference.setBoolean(IS_GOD_ON_FORCEFULLY, data.app.is_forcefully);
        preference.setBoolean(IS_GOD_CALLBACK_ON, data.app.is_god_callback_on);
        preference.setString(GOD_URL, data.app.god_url);
        preference.setString(GOD_COUNTRY, data.app.god_country);
        preference.setString(GOD_REF, data.app.god_ref);
        preference.setString(N_BG_COLOR, data.app.n_bg_color);
        preference.setString(N_TEXT_COLOR, data.app.n_text_color);
        preference.setString(N_BTN_COLOR, data.app.n_btn_color);
        preference.setInt(INT_COUNT, data.app.int_count);
        preference.setInt(BACK_IN_COUNT, data.app.back_in_count);
        preference.setInt(REFRESH_TIMER, data.app.refresh_timer);
        preference.setInt(INT_LOADER_SEC, data.app.int_loader_sec);
        preference.setString(G_BANNER_ID, data.app.g_banner_id);
        preference.setString(G_NATIVE_ID, data.app.g_native_id);
        preference.setString(G_INTER_ID, data.app.g_inter_id);
        preference.setString(G_REWARD_ID, data.app.g_reward_id);
        preference.setString(G_APP_OPEN_ID, data.app.g_app_open_id);
        preference.setString(F_BANNER_ID, data.app.f_banner_id);
        preference.setString(F_NATIVE_ID, data.app.f_native_id);
        preference.setString(F_INTER_ID, data.app.f_inter_id);
        preference.setString(F_REWARD_ID, data.app.f_reward_id);
        preference.setString(Q_URL, data.app.q_url);
        preference.setString(CUSTOM_ADS, new Gson().toJson(data.custom_ads));


    }

    public static void gotoAds(Context context, String url) {
        try {
            String packageName = "com.android.chrome";
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setToolbarColor(ContextCompat.getColor(context, R.color.app_color));
            CustomTabsIntent customTabsIntent = builder.build();
            customTabsIntent.intent.setPackage(packageName);
            customTabsIntent.launchUrl(context, Uri.parse(url));
        } catch (Exception e) {
            Log.e("TAG", e.toString());
        }
    }


    public interface ResponseListener {
        void onResponse(Data data);

        void onFailure(VolleyError error);
    }

    public static void gotoTerms(Context context) {
        try {
            String packageName = "com.android.chrome";
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setToolbarColor(ContextCompat.getColor(context, R.color.app_color));
            CustomTabsIntent customTabsIntent = builder.build();
            customTabsIntent.intent.setPackage(packageName);
            customTabsIntent.launchUrl(context, Uri.parse(PowerPreference.getDefaultFile().getString( AllManager.POLICY, "")));
        } catch (Exception e) {
            Log.e("", e.toString());
        }
    }
}