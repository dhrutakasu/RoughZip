package com.fancytext.nicnamegenerator.namemerger.utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.WindowManager;

import androidx.core.view.InputDeviceCompat;

import com.fancytext.nicnamegenerator.namemerger.R;


public class LoadingDialog {
    Context context;
    Dialog progressDialog;

    public boolean isCanceled = false;

    public LoadingDialog(Context context) {
        this.context = context;


        progressDialog = new Dialog(context);
        progressDialog.setContentView( R.layout.layout_dialog);

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(progressDialog.getWindow().getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        progressDialog.getWindow().setAttributes(layoutParams);
        progressDialog.setCancelable(false);
        progressDialog.getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));


    }


    public boolean isShowing() {
        return progressDialog.isShowing();
    }


    public void show() {
        progressDialog.show();
    }

    public void dismiss() {
        progressDialog.dismiss();
    }

}
