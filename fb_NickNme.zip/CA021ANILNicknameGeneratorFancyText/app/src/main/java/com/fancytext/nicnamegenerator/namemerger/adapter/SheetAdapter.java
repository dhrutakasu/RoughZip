package com.fancytext.nicnamegenerator.namemerger.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.fancytext.nicnamegenerator.namemerger.Interface.RecyclerViewItem;
import com.fancytext.nicnamegenerator.namemerger.R;

import java.util.ArrayList;

public class SheetAdapter extends RecyclerView.Adapter<SheetAdapter.MyViewHolder> {
    Context context;
    RecyclerViewItem recyclerViewItem;
    ArrayList<String> symbols;

    public SheetAdapter(Context context2, ArrayList<String> symbols2, RecyclerViewItem recyclerViewItem2) {
        this.context = context2;
        this.symbols = symbols2;
        this.recyclerViewItem = recyclerViewItem2;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder( LayoutInflater.from( this.context ).inflate( R.layout.list_item_sheet, parent, false ) );
    }

    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        holder.symbol.setText( this.symbols.get( position ) );
        holder.itemView.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                SheetAdapter.this.recyclerViewItem.onItemClick( holder.getAdapterPosition(), SheetAdapter.this.symbols.get( position ) );
            }
        } );
    }

    public int getItemCount() {
        return this.symbols.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: private */
        public TextView symbol;

        private MyViewHolder(View itemView) {
            super( itemView );
            this.symbol = (TextView) itemView.findViewById( R.id.symboltxt );
        }
    }
}
