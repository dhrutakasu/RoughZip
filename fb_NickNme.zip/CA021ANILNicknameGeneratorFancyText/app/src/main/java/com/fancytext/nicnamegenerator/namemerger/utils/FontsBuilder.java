package com.fancytext.nicnamegenerator.namemerger.utils;



import com.fancytext.nicnamegenerator.namemerger.Interface.Style;
import com.fancytext.nicnamegenerator.namemerger.model.BlueEffect;
import com.fancytext.nicnamegenerator.namemerger.model.LeftEffect;
import com.fancytext.nicnamegenerator.namemerger.model.LeftRightStyle;
import com.fancytext.nicnamegenerator.namemerger.model.ReplaceEffect;
import com.fancytext.nicnamegenerator.namemerger.model.RightEffect;

import java.util.ArrayList;
import java.util.Iterator;

public class FontsBuilder {
    private static ArrayList<String> createLeft() {
        ArrayList<String> strings = new ArrayList<>();
        strings.add("๖ۣۜ");
        strings.add("⸾");
        strings.add("⸽");
        strings.add("⸾⸾");
        strings.add("⸽⸽");
        strings.add("☢");
        strings.add("☣");
        strings.add("☠");
        strings.add("⚠");
        strings.add("☤");
        strings.add("⚕");
        strings.add("⚚");
        strings.add("†");
        strings.add("☯");
        strings.add("⚖");
        strings.add("☮");
        strings.add("⚘");
        strings.add("⚔");
        strings.add("☭");
        strings.add("⚒");
        strings.add("⚓");
        strings.add("⚛");
        strings.add("⚜");
        strings.add("⚡");
        strings.add("⚶");
        strings.add("☥");
        strings.add("✠");
        strings.add("✙");
        strings.add("✞");
        strings.add("✟");
        strings.add("✧");
        strings.add("⋆");
        strings.add("★");
        strings.add("☆");
        strings.add("✪");
        strings.add("✫");
        strings.add("✬");
        strings.add("✭");
        strings.add("✮");
        strings.add("✯");
        strings.add("☸");
        strings.add("✵");
        strings.add("❂");
        strings.add("☘");
        strings.add("♡");
        strings.add("♥");
        strings.add("❤");
        strings.add("⚘");
        strings.add("❀");
        strings.add("❃");
        strings.add("❁");
        strings.add("✼");
        strings.add("☀");
        strings.add("✌");
        strings.add("♫");
        strings.add("♪");
        strings.add("☃");
        strings.add("❄");
        strings.add("❅");
        strings.add("❆");
        strings.add("☕");
        strings.add("☂");
        strings.add("❦");
        strings.add("✈");
        strings.add("♕");
        strings.add("♛");
        strings.add("♖");
        strings.add("♜");
        strings.add("☁");
        strings.add("☾");
        return strings;
    }

    private static ArrayList<Pair<String, String>> createLeftRightPair() {
        ArrayList<Pair<String, String>> list = new ArrayList<>();
        list.add(new Pair("⫷", "⫸"));
        list.add(new Pair("╰", "╯"));
        list.add(new Pair("╭", "╮"));
        list.add(new Pair("╟", "╢"));
        list.add(new Pair("╚", "╝"));
        list.add(new Pair("╔", "╗"));
        list.add(new Pair("⚞", "⚟"));
        list.add(new Pair("⟅", "⟆"));
        list.add(new Pair("⟦", "⟧"));
        list.add(new Pair("☾", "☽"));
        list.add(new Pair("【", "】"));
        list.add(new Pair("〔", "〕"));
        list.add(new Pair("《", "》"));
        list.add(new Pair("〘", "〙"));
        list.add(new Pair("『", "』"));
        list.add(new Pair("┋", "┋"));
        list.add(new Pair("[̲̅", "̲̅]"));
        return list;
    }

    private static ArrayList<String> createRight() {
        ArrayList<String> list = new ArrayList<>();
        list.add("⃠");
        list.add("̾");
        list.add("͚");
        list.add("̫");
        list.add("̏");
        list.add("͒");
        list.add("̐");
        list.add("̥");
        list.add("̃");
        list.add("♥");
        list.add("͎");
        list.add("͓̽");
        list.add("̟");
        list.add("͙");
        list.add("̺");
        list.add("͆");
        list.add("̾");
        list.add("̳");
        list.add("̲");
        list.add("̸");
        list.add("̷");
        list.add("̴");
        list.add("̶");
        for (char c : Zalgo.UP_CHARS) {
            list.add(c + "");
        }
        for (char c2 : Zalgo.DOWN_CHARS) {
            list.add(c2 + "");
        }
        for (char c3 : Zalgo.MID_CHARS) {
            list.add(c3 + "");
        }
        return list;
    }

    public static ArrayList<Style> makeStyle() {
        ArrayList<Style> encoders = new ArrayList<>();
        encoders.add(new BlueEffect());
        encoders.addAll( ReplaceEffect.createStyle());
        Iterator<Pair<String, String>> it = createLeftRightPair().iterator();
        while (it.hasNext()) {
            Pair<String, String> pair = it.next();
            encoders.add(new LeftRightStyle((String) pair.first, (String) pair.second));
        }
        Iterator<String> it2 = createLeft().iterator();
        while (it2.hasNext()) {
            encoders.add(new LeftEffect(it2.next()));
        }
        Iterator<String> it3 = createRight().iterator();
        while (it3.hasNext()) {
            encoders.add(new RightEffect(it3.next()));
        }
        return encoders;
    }

    private static class Pair<F, S> {
        F first;
        S second;

        Pair(F first2, S second2) {
            this.first = first2;
            this.second = second2;
        }
    }
}
