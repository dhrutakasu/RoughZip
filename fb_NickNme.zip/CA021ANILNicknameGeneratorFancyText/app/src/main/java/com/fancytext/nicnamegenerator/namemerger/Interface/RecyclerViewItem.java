package com.fancytext.nicnamegenerator.namemerger.Interface;

public interface RecyclerViewItem {
    void onItemClick(int i, String str);
}
