package com.fancytext.nicnamegenerator.namemerger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.android.volley.VolleyError;
import com.fancytext.nicnamegenerator.namemerger.admob.AllManager;
import com.fancytext.nicnamegenerator.namemerger.admob.App;
import com.fancytext.nicnamegenerator.namemerger.admob.AppOP;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.admob.Data;
import com.fancytext.nicnamegenerator.namemerger.admob.NewOP;
import com.fancytext.nicnamegenerator.namemerger.admob.PageChange;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityMainBinding;
import com.fancytext.nicnamegenerator.namemerger.ui.StartActivity;
import com.fancytext.nicnamegenerator.namemerger.utils.NetDialog;
import com.fancytext.nicnamegenerator.namemerger.utils.VersionDialog;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.preference.PowerPreference;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    AllManager allManager;
    App app;
    ActivityMainBinding binding;
    String notifyKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);

        allManager = new AllManager( this );
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e(TAG, "onResume: " + app);
        if (app == null) {
            new NetDialog(this, this::callServerForAdData);
        }
    }

    private void callServerForAdData() {
        Log.e(TAG, "callServerForAdData: ");
        allManager.getAdData(new AllManager.ResponseListener() {
            @Override
            public void onResponse(Data data) {
                if (!data.error && data.app != null) {
                    allManager.setAdData(data);
                    app = data.app;

                    //Update Check
                    new VersionDialog(MainActivity.this, data.app, new VersionDialog.OnUpdateListener() {
                        @Override
                        public void onUpdate() {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(data.app.url)));
                        }

                        @Override
                        public void onSkip() {
                            prepareForStartApp();
                        }
                    });
                } else {
                    Log.e(TAG, "onResponse: 1");
                    //TODO Have To Manage Here
                    new Handler().postDelayed(() -> callServerForAdData(), 1000);
                }
            }

            @Override
            public void onFailure(VolleyError error) {
                Log.e(TAG, "onFailure: ");
                new Handler().postDelayed(() -> callServerForAdData(), 1000);
            }
        });
    }

    private void prepareForStartApp() {
        startLoadAds();
        startApplication(4000);

    }
    private void startLoadAds() {
        if (app.is_on) {
            BigNat.getInstance(this).load();
            PageChange.getInstance(this).load();
            BackInt.getInstance(this).load();
            AppOP.getInstance().load();
            if (app.is_splash_open) {
                NewOP.getInstance().loadOpenAd(this);
            }
        }
    }

    private void startApplication(long mil) {
        new Handler().postDelayed(() -> {
            if (app.is_on && app.is_splash_open) {
                NewOP.getInstance().showOpenAd(this, () -> {
                    startActivity(new Intent(MainActivity.this, StartActivity.class).putExtra("key",notifyKey));
                    finish();
                });
            } else {
                startActivity(new Intent(MainActivity.this, StartActivity.class).putExtra("key",notifyKey));
                finish();
            }
        }, mil);
    }


}