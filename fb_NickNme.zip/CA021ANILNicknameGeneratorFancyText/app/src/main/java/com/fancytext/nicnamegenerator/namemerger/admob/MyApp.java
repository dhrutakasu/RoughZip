package com.fancytext.nicnamegenerator.namemerger.admob;

import android.app.Application;

import com.facebook.ads.AudienceNetworkAds;

public class MyApp extends Application {
    public static MyApp instance;

    @Override
    public void onCreate() {
        super.onCreate();

        //Initialize Ad Modules Here
        AudienceNetworkAds.initialize(this);

    }

    public MyApp() {
        instance = this;
    }

    public static MyApp getInstance() {
        if (instance == null)
            instance = new MyApp();
        return instance;
    }

}
