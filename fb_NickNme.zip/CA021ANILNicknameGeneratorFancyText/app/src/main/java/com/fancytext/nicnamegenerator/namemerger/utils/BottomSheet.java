package com.fancytext.nicnamegenerator.namemerger.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fancytext.nicnamegenerator.namemerger.Interface.RecyclerViewItem;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.adapter.SheetAdapter;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.Objects;

public class BottomSheet {
    /* access modifiers changed from: private */
    public BottomSheetDialog bottomSheetDialog;

    public static void showDialogbox(final Context context, final EditText editText) {
        new BottomSheetDialog(context);
        View view = LayoutInflater.from(context).inflate( R.layout.sheet_symbols, (ViewGroup) null);
        BottomSheetDialog bottomSheetDialog2 = new BottomSheetDialog(context, R.style.BottomSheetDialog);
        bottomSheetDialog2.setContentView(view);
        ((ImageButton) view.findViewById(R.id.back_delete)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int length = editText.getText().length();
                if (length > 0) {
                    editText.getText().delete(length - 1, length);
                }
            }
        });
        ((ImageButton) view.findViewById(R.id.delete)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editText.getText().clear();
            }
        });
        RadioGroup group = (RadioGroup) view.findViewById(R.id.radio_group_sym);
        group.check(R.id.rd1);
        final RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recyclerviewSheet);
        recyclerView.setLayoutManager(new GridLayoutManager(context, 5));
        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rd1) {


                    recyclerView.setAdapter(new SheetAdapter(context, BottomSheet.getSymbols(context.getString(R.string.SYM1)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.getEditableText().insert(Math.max(editText.getSelectionStart(), 0), sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd2) {
                    Context context2 = context;
                    recyclerView.setAdapter(new SheetAdapter(context2, BottomSheet.getSymbols(context2.getString(R.string.SYM2)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd3) {
                    Context context3 = context;
                    recyclerView.setAdapter(new SheetAdapter(context3, BottomSheet.getSymbols(context3.getString(R.string.SYM3)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd4) {
                    Context context4 = context;
                    recyclerView.setAdapter(new SheetAdapter(context4, BottomSheet.getSymbols(context4.getString(R.string.SYM4)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd5) {
                    Context context5 = context;
                    recyclerView.setAdapter(new SheetAdapter(context5, BottomSheet.getSymbols(context5.getString(R.string.SYM5)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd6) {
                    Context context6 = context;
                    recyclerView.setAdapter(new SheetAdapter(context6, BottomSheet.getSymbols(context6.getString(R.string.SYM6)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd7) {
                    Context context7 = context;
                    recyclerView.setAdapter(new SheetAdapter(context7, BottomSheet.getSymbols(context7.getString(R.string.SYM7)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd8) {
                    Context context8 = context;
                    recyclerView.setAdapter(new SheetAdapter(context8, BottomSheet.getSymbols(context8.getString(R.string.SYM8)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd9) {
                    Context context9 = context;
                    recyclerView.setAdapter(new SheetAdapter(context9, BottomSheet.getSymbols(context9.getString(R.string.SYM9)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd10) {
                    Context context10 = context;
                    recyclerView.setAdapter(new SheetAdapter(context10, BottomSheet.getSymbols(context10.getString(R.string.SYM10)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.getEditableText().insert(Math.max(editText.getSelectionStart(), 0), sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd11) {
                    Context context11 = context;
                    recyclerView.setAdapter(new SheetAdapter(context11, BottomSheet.getSymbols(context11.getString(R.string.SYM11)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd12) {
                    Context context12 = context;
                    recyclerView.setAdapter(new SheetAdapter(context12, BottomSheet.getSymbols(context12.getString(R.string.SYM12)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
                if (checkedId == R.id.rd13) {
                    Context context13 = context;
                    recyclerView.setAdapter(new SheetAdapter(context13, BottomSheet.getSymbols(context13.getString(R.string.SYM13)), new RecyclerViewItem() {
                        public void onItemClick(int position, String sym) {
                            editText.append(sym);
                        }
                    }));
                }
            }
        });
        recyclerView.setAdapter(new SheetAdapter(context, getSymbols(context.getString(R.string.SYM1)), new RecyclerViewItem() {
            public void onItemClick(int position, String sym) {
                editText.append(sym);
            }
        }));
        ((Window) Objects.requireNonNull(bottomSheetDialog2.getWindow())).setDimAmount(0.0f);
        bottomSheetDialog2.show();
    }

    /* access modifiers changed from: private */
    public static ArrayList<String> getSymbols(String ss) {
        String[] sym = ss.split(" ");
        ArrayList<String> list = new ArrayList<>();
        for (String s : sym) {
            if (s != null && !s.trim().equals("")) {
                list.add(s);
            }
        }
        return list;
    }

    public void styleBottom(Context context, final String text) {
        final CopyHandler copyHandler = new CopyHandler(context);
        this.bottomSheetDialog = new BottomSheetDialog(context, R.style.BottomSheetDialog);
        View view = LayoutInflater.from(context).inflate(R.layout.bottom_preview, (ViewGroup) null);
        ((ImageButton) view.findViewById(R.id.copybtn)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyHandler.copy(text);
            }
        });
        ((ImageButton) view.findViewById(R.id.sharebtn)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyHandler.Share(text);
            }
        });
        ((ImageButton) view.findViewById(R.id.backbtn)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                BottomSheet.this.bottomSheetDialog.hide();
            }
        });
        ((TextView) view.findViewById(R.id.preview_font)).setText(text);
        BottomSheetDialog bottomSheetDialog2 = new BottomSheetDialog(context);
        this.bottomSheetDialog = bottomSheetDialog2;
        bottomSheetDialog2.setContentView(view);
        this.bottomSheetDialog.show();
    }
}
