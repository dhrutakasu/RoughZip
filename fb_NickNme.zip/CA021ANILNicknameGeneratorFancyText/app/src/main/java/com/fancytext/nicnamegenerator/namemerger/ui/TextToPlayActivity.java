package com.fancytext.nicnamegenerator.namemerger.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;

import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityTextToPlayBinding;
import com.fancytext.nicnamegenerator.namemerger.utils.CopyHandler;

import java.util.HashMap;
import java.util.Map;

public class TextToPlayActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityTextToPlayBinding binding;

    String flippedReversedText, reversedText, flippedText;
    private static final Map<Character, Character> flipMap = new HashMap<>();

    static {
        flipMap.put('a', '\u0250');
        flipMap.put('b', 'q');
        flipMap.put('c', '\u0254');
        flipMap.put('d', 'p');
        flipMap.put('e', '\u01DD');
        flipMap.put('f', 'ɟ');
        flipMap.put('g', 'ƃ');
        flipMap.put('h', 'ɥ');
        flipMap.put('i', 'ᴉ');
        flipMap.put('j', 'ɾ');
        flipMap.put('k', 'ʞ');
        flipMap.put('l', 'l');
        flipMap.put('m', 'ɯ');
        flipMap.put('n', 'u');
        flipMap.put('o', 'o');
        flipMap.put('p', 'd');
        flipMap.put('q', 'b');
        flipMap.put('r', 'ɹ');
        flipMap.put('s', 's');
        flipMap.put('t', 'ʇ');
        flipMap.put('u', 'n');
        flipMap.put('v', 'ʌ');
        flipMap.put('w', 'ʍ');
        flipMap.put('x', 'x');
        flipMap.put('y', 'ʎ');
        flipMap.put('z', 'z');

        // Flipped versions of uppercase letters
        flipMap.put('A', '\u2200'); // Flipped 'A'
        flipMap.put('C', '\u0186'); // Flipped 'C'
        flipMap.put('D', 'ᗡ'); // Flipped 'D'
        flipMap.put('E', '\u018e'); // Flipped 'E'
        flipMap.put('F', 'Ⅎ'); // Flipped 'F'
        flipMap.put('G', '⅁'); // Flipped 'G'
        flipMap.put('H', 'H'); // Flipped 'H'
        flipMap.put('I', 'I'); // Flipped 'I'
        flipMap.put('J', 'ſ'); // Flipped 'J'
        flipMap.put('K', 'ʞ'); // Flipped 'K'
        flipMap.put('L', '˥'); // Flipped 'L'
        flipMap.put('M', 'W'); // Flipped 'M'
        flipMap.put('N', 'N'); // Flipped 'N'
        flipMap.put('O', 'O'); // Flipped 'O'
        flipMap.put('P', 'Ԁ'); // Flipped 'P'
        flipMap.put('Q', 'Ό'); // Flipped 'Q'
        flipMap.put('R', 'ᴚ'); // Flipped 'R'
        flipMap.put('S', 'S'); // Flipped 'S'
        flipMap.put('T', '⊥'); // Flipped 'T'
        flipMap.put('U', '∩'); // Flipped 'U'
        flipMap.put('V', 'Λ'); // Flipped 'V'
        flipMap.put('W', 'M'); // Flipped 'W'
        flipMap.put('X', 'X'); // Flipped 'X'
        flipMap.put('Y', '⅄'); // Flipped 'Y'
        flipMap.put('Z', 'Z'); // Flipped 'Z'

        // Flipped versions of numeric digits
        flipMap.put('0', '0'); // Flipped '0'
        flipMap.put('1', 'Ɩ'); // Flipped '1'
        flipMap.put('2', 'ᄅ'); // Flipped '2'
        flipMap.put('3', 'Ɛ'); // Flipped '3'
        flipMap.put('4', 'ㄣ'); // Flipped '4'
        flipMap.put('5', 'ϛ'); // Flipped '5'
        flipMap.put('6', '9'); // Flipped '6'
        flipMap.put('7', 'ㄥ'); // Flipped '7'
        flipMap.put('8', '8'); // Flipped '8'
        flipMap.put('9', '6'); // Flipped '9'
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTextToPlayBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        BigNat.getInstance(this).show();

        binding.appbar.title.setText("Text TO Play");

        binding.btnCopyBoth.setOnClickListener(this);
        binding.btnCopyFlip.setOnClickListener(this);
        binding.btnCopyReverse.setOnClickListener(this);
        binding.btnShareBoth.setOnClickListener(this);
        binding.btnShareFlip.setOnClickListener(this);
        binding.btnShareReverse.setOnClickListener(this);
        binding.close22.setOnClickListener(this);
        binding.appbar.back.setOnClickListener(this);

        binding.close22.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                binding.msg.getText().clear();
                return false;
            }
        });


        binding.msg.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String inputText = s.toString();
                flippedText = flipText(inputText);
                reversedText = reverseText(inputText);
                flippedReversedText = flipText(reversedText);

                binding.flipText.setText(flippedText);
                binding.reverseText.setText(reversedText);
                binding.bothText.setText(flippedReversedText);


            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private String reverseText(String text) {
        return new StringBuilder(text).reverse().toString();
    }

    private String flipText(String text) {
        StringBuilder flippedText = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            char flippedChar = 0;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                flippedChar = flipMap.getOrDefault(c, c);
            }

            flippedText.append(flippedChar);
        }

        return flippedText.toString();
    }

    @Override
    public void onClick(View v) {
        CopyHandler copyHandler = new CopyHandler(TextToPlayActivity.this);
        switch (v.getId()) {

            case R.id.btn_copy_reverse:
                copyHandler.copy(reversedText);
                break;
            case R.id.btn_copy_flip:
                copyHandler.copy(flippedText);
                break;
            case R.id.btn_copy_both:
                copyHandler.copy(flippedReversedText);
                break;
            case R.id.btn_share_reverse:
                copyHandler.Share(reversedText);
                break;
            case R.id.btn_share_flip:
                copyHandler.Share(flippedText);
                break;
            case R.id.btn_share_both:
                copyHandler.Share(flippedReversedText);
                break;
            case R.id.close22:
                int length = binding.msg.getText().length();
                if (length > 0) {
                    binding.msg.getText().delete(length - 1, length);
                }
                break;
            case R.id.back:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}