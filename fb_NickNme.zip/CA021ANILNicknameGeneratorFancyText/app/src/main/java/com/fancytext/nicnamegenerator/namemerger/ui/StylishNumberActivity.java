package com.fancytext.nicnamegenerator.namemerger.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.View;

import com.fancytext.nicnamegenerator.namemerger.adapter.NumberAdapter;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityStylishNumberBinding;
import com.fancytext.nicnamegenerator.namemerger.utils.NumStyle;
import com.fancytext.nicnamegenerator.namemerger.utils.NumberEditText;

public class StylishNumberActivity extends AppCompatActivity {
    ActivityStylishNumberBinding binding;
    public static String name_number = "0123456789";
    public static int type = 1;
    public static NumberAdapter numberAdapter = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityStylishNumberBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);

        BigNat.getInstance(this).show();
        binding.appbar.title.setText("Stylish Number");
        binding.appbar.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        NumberAdapter numberAdapter2 = new NumberAdapter( this, NumStyle.Number, NumStyle.numberStyle, name_number, type );
        numberAdapter = numberAdapter2;
        binding.recyclerView.setAdapter( numberAdapter2 );
        binding.recyclerView.setHasFixedSize( true );
        binding.recyclerView.setLayoutManager( new LinearLayoutManager( this ) );
        this.binding.inputtextStylish.addTextChangedListener( new NumberEditText() );

        binding.closebtn.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                int length = StylishNumberActivity.this.binding.inputtextStylish.getText().length();
                if (length > 0) {
                    StylishNumberActivity.this.binding.inputtextStylish.getText().delete( length - 1, length );
                }
            }
        } );

    }

    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}