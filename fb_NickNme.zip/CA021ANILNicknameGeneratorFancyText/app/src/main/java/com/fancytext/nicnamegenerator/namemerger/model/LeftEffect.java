package com.fancytext.nicnamegenerator.namemerger.model;


import com.fancytext.nicnamegenerator.namemerger.Interface.Style;

public class LeftEffect implements Style {
    private String left;

    public LeftEffect(String left2) {
        this.left = left2;
    }

    public String generate(String text) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == ' ') {
                result.append(this.left);
                result.append(" ");
            } else {
                result.append(this.left);
                result.append(text.charAt(i));
            }
        }
        result.append(this.left);
        return result.toString();
    }

    public int hashCode() {
        return this.left.hashCode();
    }
}
