package com.fancytext.nicnamegenerator.namemerger.admob;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.util.Log;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;


import com.bumptech.glide.Glide;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.preference.PowerPreference;

import java.util.Objects;

public class NewOP {

    private static final String TAG = "NewOP";
    @SuppressLint("StaticFieldLeak")
    public static AppOpenAd newAppOpen = null;

    public static MyApp app = MyApp.getInstance();
    @SuppressLint("StaticFieldLeak")
    public static Activity activity;
    @SuppressLint("StaticFieldLeak")
    public static NewOP instance;

    public static OnAdClosedListener listener;
    public static boolean isShowing = false;
    public static boolean isLoaded = false;

    public static Dialog dialog = null;
    public static boolean isOn = false;
    public static boolean isSplashOpenOn = false;

    public static boolean isCustomOn = false;
    public static boolean isInCustom = false;


    public interface OnAdClosedListener {
        void onAdClosed();
    }


    public static NewOP getInstance() {
        if (instance == null) {
            instance = new NewOP();
        }
        isOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_ON, isOn);
        isCustomOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_CUSTOM_ON, isCustomOn);
        isSplashOpenOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_SPLASH_OPEN, isSplashOpenOn);
        isInCustom = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_IN_CUSTOM, isInCustom);
        return instance;
    }

    public void loadOpenAd(Activity objActivity) {
        Log.e(TAG, "NewOP->loadOpenAd: ");
        if (!isOn || !isSplashOpenOn) {
            return;
        }

        activity = objActivity;
        AppOpenAd.AppOpenAdLoadCallback loadCallback1 = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(AppOpenAd ad) {
                Log.e(TAG, "NewOP->onAdLoaded");
                newAppOpen = ad;
                isLoaded = true;
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                Log.e(TAG, "NewOP->onAdFailedToLoad: " + loadAdError.toString());
                newAppOpen = null;
            }
        };

        final String appOpenAd = PowerPreference.getDefaultFile().getString( AllManager.G_APP_OPEN_ID);
        AdRequest request = getAdRequest();
        AppOpenAd.load(app, appOpenAd, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback1);

    }

    public void showOpenAd(Activity objActivity, OnAdClosedListener onAdClosedListener) {
        Log.e(TAG, "showOpenAd: ");
        if (!isOn && !isSplashOpenOn) {
            onAdClosedListener.onAdClosed();
            return;
        }
        activity = objActivity;
        listener = onAdClosedListener;


        if (newAppOpen != null && !isShowing) {
            Log.e(TAG, "showOpenAd:Not Null ");
            FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    Log.e(TAG, "newAppOpen->onAdDismissedFullScreenContent: ");
                    newAppOpen = null;
                    isShowing = false;
                    listener.onAdClosed();

                    //TODO think about it

                }

                @Override
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                    Log.e(TAG, "newAppOpen->onAdFailedToShowFullScreenContent: " + adError.toString());
                    newAppOpen = null;
                    isShowing = false;

                    listener.onAdClosed();

                    ////TODO think about it
                    showCustomAppOpen();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    isShowing = true;
                }
            };

            newAppOpen.setFullScreenContentCallback(fullScreenContentCallback);
            newAppOpen.show(activity);

        } else if (!isShowing) {
            showCustomAppOpen();
        } else {
            onAdClosedListener.onAdClosed();
        }

    }

    private void showCustomAppOpen() {
        if (!isCustomOn) {
            listener.onAdClosed();
            return;
        }
        try {

            dialog = new Dialog(activity);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView( R.layout.custom_open);
            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

            LinearLayout customAdLayout = dialog.findViewById(R.id.custom_ad_layout);
            LinearLayout customAdsClose = dialog.findViewById(R.id.custom_ad_close);
            ImageView customMedia = dialog.findViewById(R.id.custom_media);
            ImageView customLogo = dialog.findViewById(R.id.custom_logo);
            TextView customAdTitle = dialog.findViewById(R.id.custom_ad_title);
            TextView customAdBody = dialog.findViewById(R.id.custom_ad_body);
            TextView customAdBtn = dialog.findViewById(R.id.custom_ad_btn);
            CardView customAppBG = dialog.findViewById(R.id.custom_app_bg);

            dialog.show();
            AllManager adManager = new AllManager(activity);

            if (isInCustom) {
                if (PowerPreference.getDefaultFile().getInt("q_open", 0) >= 5) {
                    PowerPreference.getDefaultFile().putInt("q_open", 0);
                }

                customAdBtn.getBackground().setTint(Color.parseColor(PowerPreference.getDefaultFile().getString( AllManager.N_BTN_COLOR)));

                Glide.with(activity).load( AllManager.adsQurekaInters[PowerPreference.getDefaultFile().getInt("q_open", 0)]).into(customMedia);
                Glide.with(activity).load( AllManager.adsQurekaGifInters[PowerPreference.getDefaultFile().getInt("q_open", 0)]).into(customLogo);


                customAdLayout.setOnClickListener(view -> AllManager.gotoAds(activity, PowerPreference.getDefaultFile().getString( AllManager.Q_URL)));

                int top = PowerPreference.getDefaultFile().getInt("q_open", 0) + 1;
                PowerPreference.getDefaultFile().putInt("q_open", top == 5 ? 0 : top);


            } else {
                CustomAd customAd = adManager.getCustomAd( AllManager.AD_APP_OPEN);

                Glide.with(activity).load( AllManager.BASE_URL + customAd.media_image).into(customMedia);
                Glide.with(activity).load( AllManager.BASE_URL + customAd.logo).into(customLogo);
                customAdTitle.setText(customAd.title);
                customAdTitle.setTextColor(Color.parseColor(customAd.text_color));
                customAdBody.setText(customAd.description);
                customAdBody.setTextColor(Color.parseColor(customAd.text_color));
                customAdBtn.setText(customAd.btn_text);
                customAdBtn.setTextColor(Color.parseColor(customAd.btn_text_color));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    customAdBtn.getBackground().setTint(Color.parseColor(customAd.btn_color));
                }
                customAppBG.setCardBackgroundColor(Color.parseColor(customAd.bg_color));


                customAdLayout.setOnClickListener(view -> AllManager.gotoAds(activity, customAd.url));

            }

            customAdsClose.setOnClickListener(view -> dialog.dismiss());


            dialog.setOnShowListener(dialog -> isShowing = true);

            dialog.setOnDismissListener(dialog -> {

                isShowing = false;

                activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);


                if (NewOP.listener != null)
                    NewOP.listener.onAdClosed();
            });


        } catch (Exception e) {
            Log.w("Catch", Objects.requireNonNull(e.getMessage()));
        }
    }


    private static AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }
}
