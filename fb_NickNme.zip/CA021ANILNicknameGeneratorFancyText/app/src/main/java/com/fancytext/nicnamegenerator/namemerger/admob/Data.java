package com.fancytext.nicnamegenerator.namemerger.admob;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Data implements Serializable {
    @SerializedName("error")
    public boolean error;
    @SerializedName("message")
    public String message;
    @SerializedName("application")
    public App app;
    @SerializedName("custom_ads")
    public CustomAd[] custom_ads;
}