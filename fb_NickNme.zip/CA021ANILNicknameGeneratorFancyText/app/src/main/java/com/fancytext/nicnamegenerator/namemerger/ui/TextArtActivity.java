package com.fancytext.nicnamegenerator.namemerger.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.View;

import com.fancytext.nicnamegenerator.namemerger.adapter.TextAdapter;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.arts.Arts;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityTextArtBinding;
import com.fancytext.nicnamegenerator.namemerger.model.listModel;

import java.util.ArrayList;

public class TextArtActivity extends AppCompatActivity {
    ActivityTextArtBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityTextArtBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        BigNat.getInstance(this).show();
        binding.appbar.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.appbar.title.setText("Text Art");

        binding.textdesignre.setLayoutManager( new LinearLayoutManager( this ) );
        binding.textdesignre.setHasFixedSize( true );
        binding.textdesignre.setAdapter( new TextAdapter( getlist(), this ) );
    }

    public ArrayList<listModel> getlist() {
        ArrayList<listModel> arrayList = new ArrayList<>();
        ArrayList<String> arrayList2 = new Arts().get();
        for (int i = 0; i < arrayList2.size(); i++) {
            arrayList.add( new listModel( arrayList2.get( i ) ) );
        }
        return arrayList;
    }
    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }

}