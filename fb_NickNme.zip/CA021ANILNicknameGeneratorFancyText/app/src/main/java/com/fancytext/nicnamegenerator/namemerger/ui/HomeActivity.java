package com.fancytext.nicnamegenerator.namemerger.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.InputDeviceCompat;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.fancytext.nicnamegenerator.namemerger.BuildConfig;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.AllManager;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.admob.PageChange;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityHomeBinding;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityHomeBinding binding;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        BigNat.getInstance(this).show();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        binding.stylishText.setOnClickListener(this);
        binding.emotionsText.setOnClickListener(this);
        binding.textToEmoji.setOnClickListener(this);
        binding.textArt.setOnClickListener(this);
        binding.proNikname.setOnClickListener(this);
        binding.stylishNumber.setOnClickListener(this);
        binding.textRepeter.setOnClickListener(this);
        binding.textToPlay.setOnClickListener(this);
        binding.setting.setOnClickListener(this);

        binding.navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                binding.drawer.closeDrawers();
                switch (menuItem.getItemId()) {
                    case R.id.share:
                        try {
                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                            shareIntent.setType("text/plain");
                            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Install this app");
                            String shareMessage = "\nLet me recommend you this application\n\n";
                            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                            startActivity(Intent.createChooser(shareIntent, "choose one"));
                        } catch (Exception e) {
                            //e.toString();
                        }
                        return true;
                    case R.id.privacyPolicy:
                        AllManager.gotoTerms(HomeActivity.this);
                        return true;
                    case R.id.rate:
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
                        } catch (ActivityNotFoundException e) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                        }
                        return true;

                    default:
                        return true;
                }
            }
        });
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, binding.drawer, toolbar, R.string.nav_open, R.string.nav_close) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };
        binding.drawer.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.stylish_text:
                PageChange.getInstance(this,()->{
                    Intent intent=new Intent(HomeActivity.this,StylishTextActivity.class);
                    intent.putExtra("name", "Stylish Text");
                    startActivity(intent);
                }).show();

                break;
            case R.id.pro_nikname:
                PageChange.getInstance(this,()->{
                    Intent intent1=new Intent(HomeActivity.this,StylishTextActivity.class);
                    intent1.putExtra("name", "Pro Nickname");
                    startActivity(intent1);
                }).show();

                break;
            case R.id.emotions_text:
                PageChange.getInstance(this,()->{
                    startActivity(new Intent(this,EmotionActivity.class));
                }).show();

                break;
            case R.id.text_to_emoji:
                PageChange.getInstance(this,()->{
                    startActivity(new Intent(this,TextToEmojiActivity.class));
                }).show();

                break;
            case R.id.text_art:
                PageChange.getInstance(this,()->{
                    startActivity(new Intent(this,TextArtActivity.class));
                }).show();

                break;
            case R.id.stylish_number:
                PageChange.getInstance(this,()->{
                    startActivity(new Intent(this,StylishNumberActivity.class));
                }).show();

                break;
            case R.id.text_repeter:
                PageChange.getInstance(this,()->{
                    startActivity(new Intent(this,TextRepeterActivity.class));
                }).show();

                break;
            case R.id.text_to_play:
                PageChange.getInstance(this,()->{
                    startActivity(new Intent(this,TextToPlayActivity.class));
                }).show();

                break;
            case R.id.setting:
                binding.drawer.openDrawer(GravityCompat.START);
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}