package com.fancytext.nicnamegenerator.namemerger.utils;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;


public class CopyHandler {
    private Context context;


    public CopyHandler(Context context2) {
        this.context = context2;

    }

    public void copy(String data) {
        if (data.isEmpty()) {
            return;
        }
        ClipboardManager clipboardManager = (ClipboardManager) this.context.getSystemService( Context.CLIPBOARD_SERVICE);
        Context context2 = this.context;
        ClipData clip = ClipData.newPlainText("simple text", data);
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(clip);
        }


    }

    public void Share(String data) {
        if (data.isEmpty()) {
            return;
        }
        try {
            Intent i = new Intent("android.intent.action.SEND");
            i.setType("text/plain");
            i.putExtra("android.intent.extra.TEXT", data);
            this.context.startActivity(Intent.createChooser(i, "choose one"));
        } catch (Exception e) {
        }

    }

    public void copysi(String data) {
        if (data.isEmpty()) {
            return;
        }
        ClipboardManager clipboardManager = (ClipboardManager) this.context.getSystemService( Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("simple text", data);
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(clip);
        }

    }
}
