package com.fancytext.nicnamegenerator.namemerger.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.model.listModel;
import com.fancytext.nicnamegenerator.namemerger.utils.CopyHandler;

import java.util.List;

public class TextAdapter extends RecyclerView.Adapter<TextAdapter.ViewHolder> {
    private Activity context;
    private List<listModel> list;

    public TextAdapter(List<listModel> arrayList, Activity context2) {
        this.list = arrayList;
        this.context = context2;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( context ).inflate( R.layout.item_text, parent, false );
        return new ViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

   /*     if (position % 10 == 0) {
            holder.ad.setVisibility(View.VISIBLE);
            BigNat.getInstance((Activity) context).showListNativeAds(holder.adLayout, holder.adText);
        } else {
            holder.ad.setVisibility(View.GONE);
        }*/
        holder.arts.setText( this.list.get( position ).get_name() );
        holder.num.setText( String.valueOf( position + 1 ) );
        final CopyHandler copyHandler = new CopyHandler( this.context );
        final String text = holder.arts.getText().toString();
        holder.copy.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                copyHandler.copy( text );
            }
        } );
        holder.share.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                copyHandler.Share( text );
            }
        } );
    }


    public int getItemCount() {
        return this.list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView arts, adText;
        ImageButton copy;
        TextView num;
        ImageButton share;
        LinearLayout ad;
        FrameLayout adLayout;

        public ViewHolder(@NonNull View itemView) {
            super( itemView );
            this.num = (TextView) itemView.findViewById( R.id.numk );
            this.copy = (ImageButton) itemView.findViewById( R.id.btn_copy6 );
            this.share = (ImageButton) itemView.findViewById( R.id.btn_share6 );
            this.arts = (TextView) itemView.findViewById( R.id.text_designs );
/*            this.ad=(LinearLayout) itemView.findViewById( R.id.ads );
            this.adText=(TextView) itemView.findViewById( R.id.ad_space );
            this.adLayout=(FrameLayout) itemView.findViewById( R.id.native_ad );*/
        }
    }
}
