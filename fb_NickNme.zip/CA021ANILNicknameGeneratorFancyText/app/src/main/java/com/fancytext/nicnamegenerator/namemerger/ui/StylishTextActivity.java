package com.fancytext.nicnamegenerator.namemerger.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.fancytext.nicnamegenerator.namemerger.adapter.FontAdapter;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityStylishTextBinding;
import com.fancytext.nicnamegenerator.namemerger.utils.BottomSheet;
import com.fancytext.nicnamegenerator.namemerger.utils.FontsGenerator;

public class StylishTextActivity extends AppCompatActivity {
    ActivityStylishTextBinding binding;
    public FontAdapter mAdapter;
    public FontsGenerator mGenerator;
    private SharedPreferences.Editor editor;
    private SharedPreferences sharedPreferences;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityStylishTextBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        mGenerator = new FontsGenerator( this );

        BigNat.getInstance(this).show();
        binding.appbar.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        name=getIntent().getStringExtra("name");
        binding.appbar.title.setText(name);

        restoreText();

        binding.recycleViewFF.setLayoutManager( new LinearLayoutManager( this ) );
        binding.recycleViewFF.setHasFixedSize( true );

        mAdapter = new FontAdapter( this );
        binding.recycleViewFF.setAdapter( mAdapter );

        binding.symbols.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheet.showDialogbox( StylishTextActivity.this, binding.editTextFF );
            }
        } );

        binding.closebtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int length = StylishTextActivity.this.binding.editTextFF.getText().length();
                if (length > 0) {
                    StylishTextActivity.this.binding.editTextFF.getText().delete( length - 1, length );
                }
            }
        } );

        binding.closebtn.setOnLongClickListener( new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                StylishTextActivity.this.binding.editTextFF.getText().clear();
                return false;
            }
        } );

        binding.editTextFF.addTextChangedListener( new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                convertText( binding.editTextFF.getText().toString() );
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        } );



    }
    private void convertText(String inp) {
        if (inp.isEmpty()) {
            inp = "Fancy Text";
        }
        this.mAdapter.setData( this.mGenerator.generate( inp ) );
    }
    private void restoreText() {
        SharedPreferences sharedPreferences2 = this.getSharedPreferences( "MyPre", 0 );
        this.sharedPreferences = sharedPreferences2;
        SharedPreferences.Editor edit = sharedPreferences2.edit();
        this.editor = edit;
        edit.apply();
        binding.editTextFF.setText( this.sharedPreferences.getString( "FontFragment1", "" ) );
    }

    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}