package com.fancytext.nicnamegenerator.namemerger.utils;

import java.util.Random;

public class Zalgo {
    public static final char[] DOWN_CHARS = {790, 791, 792, 793, 796, 797, 798, 799, 800, 804, 805, 806, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 825, 826, 827, 828, 837, 839, 840, 841, 845, 846, 851, 852, 853, 854, 857, 858, 803};
    public static final char[] MID_CHARS = {789, 795, 832, 833, 856, 801, 802, 807, 808, 820, 821, 822, 847, 860, 861, 862, 863, 864, 866, 824, 823, 865, 1161};
    public static final char[] UP_CHARS = {781, 782, 772, 773, 831, 785, 774, 784, 850, 855, 849, 775, 776, 778, 834, 835, 836, 842, 843, 844, 771, 770, 780, 848, 768, 769, 779, 783, 786, 787, 788, 829, 777, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 830, 859, 838, 794};

    private static boolean isZalgo(char c) {
        for (char upChar : UP_CHARS) {
            if (c == upChar) {
                return true;
            }
        }
        for (char downChar : DOWN_CHARS) {
            if (c == downChar) {
                return true;
            }
        }
        for (char midChar : MID_CHARS) {
            if (c == midChar) {
                return true;
            }
        }
        return false;
    }

    public static String generate(String source, int up, int mid, int down) {
        StringBuilder result = new StringBuilder();
        Random rand = new Random(System.currentTimeMillis());
        for (int i = 0; i < source.length(); i++) {
            if (!isZalgo(source.charAt(i))) {
                result.append(source.charAt(i));
                int midCharCount = 0;
                int upCharCount = up > 0 ? rand.nextInt(up) : 0;
                int downCharCount = down > 0 ? rand.nextInt(down) : 0;
                if (mid > 0) {
                    midCharCount = rand.nextInt(mid);
                }
                for (int j = 0; j < upCharCount; j++) {
                    char[] cArr = UP_CHARS;
                    result.append(cArr[rand.nextInt(cArr.length)]);
                }
                for (int j2 = 0; j2 < downCharCount; j2++) {
                    char[] cArr2 = DOWN_CHARS;
                    result.append(cArr2[rand.nextInt(cArr2.length)]);
                }
                for (int j3 = 0; j3 < midCharCount; j3++) {
                    char[] cArr3 = MID_CHARS;
                    result.append(cArr3[rand.nextInt(cArr3.length)]);
                }
            }
        }
        return result.toString();
    }

    public static String generate(String source) {
        return generate(source, 16, 6, 16);
    }
}
