package com.fancytext.nicnamegenerator.namemerger.admob;

import static androidx.lifecycle.Lifecycle.Event.ON_START;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;


import com.bumptech.glide.Glide;
import com.fancytext.nicnamegenerator.namemerger.MainActivity;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.preference.PowerPreference;

import java.util.Objects;

public class AppOP implements LifecycleObserver, android.app.Application.ActivityLifecycleCallbacks{

    private static final String TAG = "AppOP";
    @SuppressLint("StaticFieldLeak")
    public static AppOP mAppAds;
    private static final String LOG_TAG = "AppOpenManager";
    private AppOpenAd appOpenAd = null;

    Dialog dialog = null;
    private final MyApp app = MyApp.getInstance();
    private Activity currentActivity;

    private static boolean isShowing = false;
    private static boolean isLoaded = false;
    public static boolean isOn = false;

    public boolean isCustomOn = false;
    public static boolean isInCustom = false;


    public AppOP() {
        isOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_ON, isOn);
        isCustomOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_CUSTOM_ON, isCustomOn);
        isInCustom = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_IN_CUSTOM, isInCustom);
        if (mAppAds == null) {
            mAppAds = this;
            app.registerActivityLifecycleCallbacks(this);
            ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        }
    }

    public static AppOP getInstance() {
        return new AppOP();
    }

    public void load() {
        if (!isOn) {
            return;
        }

        Log.e(TAG, "loadOpenAd: ");
        AppOpenAd.AppOpenAdLoadCallback loadCallback1 = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(AppOpenAd ad) {
                appOpenAd = ad;
                isLoaded = true;
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                AppOP.this.appOpenAd = null;
            }
        };

        final String appOpenAd = PowerPreference.getDefaultFile().getString( AllManager.G_APP_OPEN_ID);
        AdRequest request = getAdRequest();
        AppOpenAd.load(app, appOpenAd, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback1);

    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    public void show() {
        if (!isOn) {
            return;
        }
        if (appOpenAd != null && !isShowing) {

            FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    appOpenAd = null;
                    isShowing = false;
                    load();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                    appOpenAd = null;
                    isShowing = false;
                    load();
                    showCustomAppOpen();
                }

                @Override
                public void onAdShowedFullScreenContent() {
                    isShowing = true;
                }
            };

            appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
            appOpenAd.show(currentActivity);

        } else if (!isShowing) {
            load();
            showCustomAppOpen();
        }
    }

    private void showCustomAppOpen() {
        if (!isCustomOn) {
            return;
        }
        try {
            dialog = new Dialog(currentActivity);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView( R.layout.custom_open);
            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

            LinearLayout customAdLayout = dialog.findViewById(R.id.custom_ad_layout);
            LinearLayout customAdsClose = dialog.findViewById(R.id.custom_ad_close);
            ImageView customMedia = dialog.findViewById(R.id.custom_media);
            ImageView customLogo = dialog.findViewById(R.id.custom_logo);
            TextView customAdTitle = dialog.findViewById(R.id.custom_ad_title);
            TextView customAdBody = dialog.findViewById(R.id.custom_ad_body);
            TextView customAdBtn = dialog.findViewById(R.id.custom_ad_btn);
            CardView customAppBG = dialog.findViewById(R.id.custom_app_bg);

            dialog.show();

            AllManager adManager = new AllManager(currentActivity);

            if (isInCustom) {
                if (PowerPreference.getDefaultFile().getInt("qa_open", 0) >= 5) {
                    PowerPreference.getDefaultFile().putInt("qa_open", 0);
                }

                customAdBtn.getBackground().setTint(Color.parseColor(PowerPreference.getDefaultFile().getString( AllManager.N_BTN_COLOR)));

                Glide.with(currentActivity).load( AllManager.adsQurekaInters[PowerPreference.getDefaultFile().getInt("qa_open", 0)]).into(customMedia);
                Glide.with(currentActivity).load( AllManager.adsQurekaGifInters[PowerPreference.getDefaultFile().getInt("qa_open", 0)]).into(customLogo);


                customAdLayout.setOnClickListener(view -> AllManager.gotoAds(currentActivity, PowerPreference.getDefaultFile().getString( AllManager.Q_URL)));

                int top = PowerPreference.getDefaultFile().getInt("qa_open", 0) + 1;
                PowerPreference.getDefaultFile().putInt("qa_open", top == 5 ? 0 : top);


            } else {
                CustomAd customAd = adManager.getCustomAd( AllManager.AD_APP_OPEN);

                Glide.with(currentActivity).load( AllManager.BASE_URL + customAd.media_image).into(customMedia);
                Glide.with(currentActivity).load( AllManager.BASE_URL + customAd.logo).into(customLogo);
                customAdTitle.setText(customAd.title);
                customAdTitle.setTextColor(Color.parseColor(customAd.text_color));
                customAdBody.setText(customAd.description);
                customAdBody.setTextColor(Color.parseColor(customAd.text_color));
                customAdBtn.setText(customAd.btn_text);
                customAdBtn.setTextColor(Color.parseColor(customAd.btn_text_color));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    customAdBtn.getBackground().setTint(Color.parseColor(customAd.btn_color));
                }
                customAppBG.setCardBackgroundColor(Color.parseColor(customAd.bg_color));


                customAdLayout.setOnClickListener(view -> AllManager.gotoAds(currentActivity, customAd.url));

            }
            customAdsClose.setOnClickListener(view -> dialog.dismiss());


            dialog.setOnShowListener(dialog -> isShowing = true);

            dialog.setOnDismissListener(dialog -> {

                isShowing = false;


            });


        } catch (Exception e) {
            Log.w("Catch", Objects.requireNonNull(e.getMessage()));
        }
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {

        if (isOn) {
            if (currentActivity != null && !(currentActivity instanceof MainActivity)) {
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                } else {
                    if (isLoaded) {
                        show();
                    } else {
                        new Handler().postDelayed(this::show, 2000);
                    }

                }
            }
        }
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityResumed(Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStopped(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        currentActivity = null;
    }
}
