package com.fancytext.nicnamegenerator.namemerger.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.adapter.EmojiAdapter;
import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.admob.PageChange;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityEmotionBinding;
import com.fancytext.nicnamegenerator.namemerger.utils.ItemClickListner;

import java.util.ArrayList;
import java.util.Arrays;

public class EmotionActivity extends AppCompatActivity implements ItemClickListner {
    ActivityEmotionBinding binding;
    int[] icon = new int[]{R.drawable.love, R.drawable.happy, R.drawable.music, R.drawable.animal, R.drawable.angry, R.drawable.sad, R.drawable.sleeping, R.drawable.excited, R.drawable.hungry, R.drawable.shy, R.drawable.other, R.drawable.kiss, R.drawable.smile, R.drawable.laugh};
    String[] logos = {"Love", "Happy", "Music", "Animals", "Angry", "Sad", "Sleeping", "Excited", "Hungry", "Shy", "Other", "Kiss", "Smile", "Laugh"};

    ArrayList<Integer> iconList = new ArrayList<>();
    ArrayList<String> logoesList = new ArrayList<>();
    ArrayList<Integer> tempIcon = new ArrayList<>();
    ArrayList<String> tempLogo = new ArrayList<>();
    EmojiAdapter emojiAdapter;
    private final int sNativeAdsCount = 14;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityEmotionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);


        binding.appbar.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.appbar.title.setText("Emotions");

        for (int j : icon) {
            iconList.add( j );
        }

        logoesList.addAll( Arrays.asList( logos ) );

        for (int i = 0; i < iconList.size(); i++) {
            if (i % sNativeAdsCount == 0) {
                tempIcon.add( null );
            }
            tempIcon.add( iconList.get( i ) );
        }
        for (int i = 0; i < logoesList.size(); i++) {
            if (i % sNativeAdsCount == 0) {
                tempLogo.add( null );
            }
            tempLogo.add( logoesList.get( i ) );
        }

        GridLayoutManager manager = new GridLayoutManager( this, 2 );
        emojiAdapter = new EmojiAdapter( EmotionActivity.this, tempIcon, tempLogo, this::onclick );
        manager.setSpanSizeLookup( new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (emojiAdapter.getItemViewType( position )) {
                    case 0:
                        return 2;
                    default:
                        return 1;
                }
            }
        } );

        binding.simpleGridView.setAdapter( emojiAdapter );
        binding.simpleGridView.setHasFixedSize( true );
        binding.simpleGridView.setLayoutManager( manager );
    }

    @Override
    public void onclick(int position) {
        PageChange.getInstance(this,()->{
            Intent intent = new Intent( this, StylistEmotionActivity.class );
            intent.putExtra( "image", tempIcon.get( position ) );
            intent.putExtra( "P", logoesList.indexOf( tempLogo.get( position ) ) );
            startActivity( intent );
        }).show();

    }
    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}