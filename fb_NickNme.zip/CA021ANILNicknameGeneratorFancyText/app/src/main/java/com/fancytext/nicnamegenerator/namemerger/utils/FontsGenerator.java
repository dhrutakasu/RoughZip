package com.fancytext.nicnamegenerator.namemerger.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.fancytext.nicnamegenerator.namemerger.Interface.Style;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class FontsGenerator {
    private static final String PREF_NAME = "stylish_position.xml";
    private Context mContext;
    private ArrayList<Style> mEncoders;

    public FontsGenerator() {
        this((Context) null);
    }

    public FontsGenerator(Context context) {
        this.mContext = context;
        long time = System.currentTimeMillis();
        this.mEncoders = FontsBuilder.makeStyle();
        if (context != null) {
            sortEncoders(context);
        }
        PrintStream printStream = System.out;
        printStream.println("time = " + (System.currentTimeMillis() - time));
    }

    private void sortEncoders(Context context) {
        final HashMap<Style, Integer> positionMap = new HashMap<>();
        for (int i = 0; i < this.mEncoders.size(); i++) {
            positionMap.put(this.mEncoders.get(i), Integer.valueOf(i));
        }
        SharedPreferences pref = context.getSharedPreferences(PREF_NAME, 0);
        if (pref.getInt(Integer.toHexString(this.mEncoders.get(0).hashCode()), -1) == -1) {
            SharedPreferences.Editor editor = pref.edit();
            for (int index = 0; index < this.mEncoders.size(); index++) {
                editor.putInt(Integer.toHexString(this.mEncoders.get(index).hashCode()), index);
            }
            editor.apply();
        }
        for (int index2 = 0; index2 < this.mEncoders.size(); index2++) {
            Style style = this.mEncoders.get(index2);
            positionMap.put(style, Integer.valueOf(pref.getInt(Integer.toHexString(style.hashCode()), index2)));
        }
        Collections.sort(this.mEncoders, new Comparator<Style>() {
            public int compare(Style o1, Style o2) {
                return ((Integer) Objects.requireNonNull(positionMap.get(o1))).compareTo((Integer) Objects.requireNonNull(positionMap.get(o2)));
            }
        });
    }

    public ArrayList<String> generate(String input) {
        ArrayList<String> result = new ArrayList<>();
        Iterator<Style> it = this.mEncoders.iterator();
        while (it.hasNext()) {
            result.add(it.next().generate(input));
        }
        return result;
    }
}
