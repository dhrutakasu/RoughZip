package com.fancytext.nicnamegenerator.namemerger.model;


import com.fancytext.nicnamegenerator.namemerger.Interface.Style;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class ReplaceEffect implements Style {
    private static final String ANTROPHOBIA = "αв¢∂єfgнιנкℓмиσρqяѕтυνωχуz_,;.?!/\\'αв¢∂єfgнιנкℓмиσρqяѕтυνωχуz0123456789";
    private static final String A_CUTE = "ábćdéfǵhíjḱĺḿńőṕqŕśtúvẃxӳź_,;.?!/\\'ÁBĆDÉFǴHíJḰĹḾŃŐṔQŔśTŰVẂXӲŹ0123456789";
    private static final String CIRCLE = "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ_,;⨀?!⊘⦸'ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ0①②③④⑤⑥⑦⑧⑨";
    private static final String CURRENCY = "₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ_,;.?!/\\'₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ0123456789";
    private static final String CURVY_1 = "ค๒ƈɗﻉिﻭɦٱﻝᛕɭ๓กѻρ۹ɼรՇપ۷ฝซץչ_,;܁?!/\\'ค๒ƈɗﻉिﻭɦٱﻝᛕɭ๓กѻρ۹ɼรՇપ۷ฝซץչ0123456789";
    private static final String CURVY_2 = "αв¢∂єƒﻭнιנкℓмησρ۹яѕтυνωχуչ_,;.?!/\\'αв¢∂єƒﻭнιנкℓмησρ۹яѕтυνωχуչ0123456789";
    private static final String CURVY_3 = "ค๒ς๔єŦﻮђเןкɭ๓ภ๏קợгรՇยשฬאץչ_,;.?!/\\'ค๒ς๔єŦﻮђเןкɭ๓ภ๏קợгรՇยשฬאץչ0123456789";
    private static final String[] EFFECTS = {"ᎯᏰᏨᎠᎬᎰᎶᎻᎨᏠᏦᏝᎷᏁᎾᏢᏅᏒᏕᎿᏬᏉᏯᎲᎽᏃ_,;.?!/\\'ᎯᏰᏨᎠᎬᎰᎶᎻᎨᏠᏦᏝᎷᏁᎾᏢᏅᏒᏕᎿᏬᏉᏯᎲᎽᏃ0123456789", "ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᵟᴿˢᵀᵁᵛᵂˣᵞᶻ_,;.?!/\\'ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᵟᴿˢᵀᵁᵛᵂˣᵞᶻ0123456789", "ꍏꌃꉓꀸꍟꎇꁅꃅꀤꀭꀘ꒒ꎭꈤꂦᖘꆰꋪꌗ꓄ꀎᐯꅏꊼꌩꁴ_,;.?!/\\'ꍏꌃꉓꀸꍟꎇꁅꃅꀤꀭꀘ꒒ꎭꈤꂦᖘꆰꋪꌗ꓄ꀎᐯꅏꊼꌩꁴ0123456789", "卂乃匚ⅅ乇千Ꮆ卄丨丿Ҡㄥ爪几ㄖ卩Ɋ尺丂ㄒ凵ᐯ山乂ㄚ乙_,;.?!/\\'卂乃匚ⅅ乇千Ꮆ卄丨丿Ҡㄥ爪几ㄖ卩Ɋ尺丂ㄒ凵ᐯ山乂ㄚ乙0123456789", "ᾰ♭ḉᖱḙḟ❡ℏ!♩кℓՊℵ✺℘ǭԻṧтṳṽω✘⑂ℨ_,;.?!/\\'ᾰ♭ḉᖱḙḟ❡ℏ!♩кℓՊℵ✺℘ǭԻṧтṳṽω✘⑂ℨ0123456789", "ᎯℬℂⅅℰℱᎶℋℐᎫᏦℒℳℕᎾℙℚℛЅTUᏉᏇXᎽℤ_,;.?!/\\'ᎯℬℂⅅℰℱᎶℋℐᎫᏦℒℳℕᎾℙℚℛЅTUᏉᏇXᎽℤ0123456789", "ąβȼď€ƒǥhɨjЌℓʍɲ๏ρǭя$ţµ˅ώж¥ƶ_,;.?!/\\'ąβȼď€ƒǥhɨjЌℓʍɲ๏ρǭя$ţµ˅ώж¥ƶ0123456789", "åβçď£ƒğȟȋjķȽɱñ¤קǭȑ§țɥ√Ψ×ÿž_,;.?!/\\'åβçď£ƒğȟȋjķȽɱñ¤קǭȑ§țɥ√Ψ×ÿž0123456789", "ąþȼȡƹƒǥɦɨǰƙŁʍɲǿρǭřȿƮµ˅ώж¥ƶ_,;.?!/\\'ąþȼȡƹƒǥɦɨǰƙŁʍɲǿρǭřȿƮµ˅ώж¥ƶ0123456789", "άвςȡέғģħίјķĻмήόρqŕşţùνώxчž_,;.?!/\\'άвςȡέғģħίјķĻмήόρqŕşţùνώxчž0123456789", "ÃβČĎẸƑĞĤĮĴЌĹϻŇỖƤǪŘŜŤǗϋŴЖЎŻ_,;.?!/\\'ÃβČĎẸƑĞĤĮĴЌĹϻŇỖƤǪŘŜŤǗϋŴЖЎŻ0123456789", ANTROPHOBIA, "ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאz_,;.?!/\\'ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאz0123456789", "ĂβČĎĔŦĞĤĨĴĶĹМŃŐРQŔŚŤÚVŴЖŶŹ_,;.?!/\\'ĂβČĎĔŦĞĤĨĴĶĹМŃŐРQŔŚŤÚVŴЖŶŹ0123456789", "aвcdeғgнιjĸlмnopqrѕтυvwхyz_,;.?!/\\'aвcdeғgнιjĸlмnopqrѕтυvwхyz0123456789", "მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ_,;.?!/\\'მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ0123456789", "ÄBĊĐË₣ĠȞÏĴĶĻMŅÖPǬŖŚȚŮVŴXŸŹ_,;.?!/\\'ÄBĊĐË₣ĠȞÏĴĶĻMŅÖPǬŖŚȚŮVŴXŸŹ0123456789", "αвc∂εғgнιנкℓмησρqяsтυvωxүz_,;.?!/\\'αвc∂εғgнιנкℓмησρqяsтυvωxүz0123456789", "äḅċďệḟġḧïjḳŀṃńöṗqŕṩẗüṿẅẍÿẓ_,;.?!/\\'äḅċďệḟġḧïjḳŀṃńöṗqŕṩẗüṿẅẍÿẓ0123456789", "ḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒ_,;.?!/\\'ḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒ0123456789", "⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵_,;.?!/\\'⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵0123456789", "αвς∂єfgнιנкℓмиσρףяѕтυνωאָуz_,;.?!/\\'αвς∂єfgнιנкℓмиσρףяѕтυνωאָуz0123456789", "ḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒ_,;.?!/\\'ḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒ0123456789", "ÁßČĎĔŦĞĤĨĴĶĹМŃŐРQŔŚŤÚVŴЖŶŹ_,;.?!/\\'ÁßČĎĔŦĞĤĨĴĶĹМŃŐРQŔŚŤÚVŴЖŶŹ0123456789", "ĂбĈĎÊҒĜĤĨĴҚĹMŇÕPØŘŜŤŨVŴҲŶŽ_,;.?!/\\'ĂбĈĎÊҒĜĤĨĴҚĹMŇÕPØŘŜŤŨVŴҲŶŽ0123456789", "ąɓçdęƒɠђįʝķɭɱŋǫƥʠŗşţųvwҳƴʐ_,;.?!/\\'ąɓçdęƒɠђįʝķɭɱŋǫƥʠŗşţųvwҳƴʐ0123456789", "ꍏ♭☾◗€Ϝ❡♄♗♪ϰ↳♔♫⊙ρ☭☈ⓢ☂☋✓ω⌘☿☡_,;.?!/\\'ꍏ♭☾◗€Ϝ❡♄♗♪ϰ↳♔♫⊙ρ☭☈ⓢ☂☋✓ω⌘☿☡⓪➊➋➌➍➎➏➐➑➒", "ﾑ乃ᄃり乇ｷムんﾉﾌズﾚﾶ刀のｱゐ尺丂ｲひ√Wﾒﾘ乙_,;.?!/\\'ﾑ乃ᄃり乇ｷムんﾉﾌズﾚﾶ刀のｱゐ尺丂ｲひ√Wﾒﾘ乙０１２３４５６７８９", "ልጌርዕቿቻኗዘጎጋጕረጠክዐየዒዪነፕሁሀሠሸሃጊ_,;.?!/\\'ልጌርዕቿቻኗዘጎጋጕረጠክዐየዒዪነፕሁሀሠሸሃጊ0123456789", "ƛƁƇƊЄƑƓӇƖʆƘԼMƝƠƤƢƦƧƬƲƔƜҲƳȤ_,;.?!/\\'ƛƁƇƊЄƑƓӇƖʆƘԼMƝƠƤƢƦƧƬƲƔƜҲƳȤ０１２３４５６７８９", "მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ_,;.?!/\\'მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ0123456789"};
    private static final String FAUX_CYRILLIC = "аъсↁэfБЂіјкlмиорqѓѕтцvшхЎz_,;.?!/\\'ДБҀↁЄFБНІЈЌLМИФРQЯЅГЦVЩЖЧZ0123456789";
    private static final String FULL_WIDTH = "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ_，；．？！／\\＇ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ０１２３４５６７８９";
    public static final int MAX_LENGTH = "abcdefghijklmnopqrstuvwxyz_,;.?!/\\'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".length();
    public static final String NORMAL = "abcdefghijklmnopqrstuvwxyz_,;.?!/\\'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final String PARANORMAL = "αвcdєfghíjklmnσpqrstuvwхчz_,;.?!/\\'αвcdєfghíjklmnσpqrstuvwхчz0123456789";
    private static final String ROCK_DOT = "äḅċḋëḟġḧïjḳḷṁṅöṗqṛṡẗüṿẅẍÿż_,;.?!/\\'ÄḄĊḊЁḞĠḦЇJḲḶṀṄÖṖQṚṠṪÜṾẄẌŸŻ012ӟ456789";
    private static final String SMALL_CAP = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴩqʀꜱᴛᴜᴠᴡxyᴢ_,;.?!/\\'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴩQʀꜱᴛᴜᴠᴡxYᴢ0123456789";
    private static final String SORCERER = "ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ_,;.?!/\\'ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ0123456789";
    private static final String STROKE = "Ⱥƀȼđɇfǥħɨɉꝁłmnøᵽꝗɍsŧᵾvwxɏƶ_,;.?!/\\'ȺɃȻĐɆFǤĦƗɈꝀŁMNØⱣꝖɌSŦᵾVWXɎƵ01ƻ3456789";
    public static final ArrayList<String> STYLES;
    private static final String SUB_SCRIPT = "ₐbcdₑfgₕᵢⱼₖₗₘₙₒₚqᵣₛₜᵤᵥwₓyz_,;.?!/\\'ₐBCDₑFGₕᵢⱼₖₗₘₙₒₚQᵣₛₜᵤᵥWₓYZ₀₁₂₃₄₅₆₇₈₉";
    private static final String SUPPER_SCRIPT = "ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ_,;.?!/\\'ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿˢᵀᵁⱽᵂˣʸᶻ⁰¹²³⁴⁵⁶⁷⁸⁹";
    private String replacement = "";

    static {
        ArrayList<String> arrayList = new ArrayList<>();
        STYLES = arrayList;
        arrayList.addAll(Arrays.asList(EFFECTS));
        STYLES.add(CIRCLE);
        STYLES.add(FULL_WIDTH);
        STYLES.add(A_CUTE);
        STYLES.add(CURVY_1);
        STYLES.add(CURVY_2);
        STYLES.add(CURVY_3);
        STYLES.add(ROCK_DOT);
        STYLES.add(STROKE);
        STYLES.add(SUPPER_SCRIPT);
        STYLES.add(SUB_SCRIPT);
        STYLES.add(FAUX_CYRILLIC);
        STYLES.add(SMALL_CAP);
        STYLES.add(ANTROPHOBIA);
        STYLES.add(CURRENCY);
        STYLES.add(PARANORMAL);
        STYLES.add(SORCERER);
    }

    private ReplaceEffect(String replacement2) {
        this.replacement = replacement2;
    }

    private static StringBuilder convert(String text, String data) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char letter = text.charAt(i);
            int index = NORMAL.indexOf(letter);
            result.append(index != -1 ? data.charAt(index) : letter);
        }
        return result;
    }

    public static ArrayList<String> convert(String text) {
        ArrayList<String> arrayList = new ArrayList<>();
        Iterator<String> it = STYLES.iterator();
        while (it.hasNext()) {
            arrayList.add(convert(text, it.next()).toString());
        }
        return arrayList;
    }

    public static ArrayList<Style> createStyle() {
        ArrayList<Style> styles = new ArrayList<>();
        Iterator<String> it = STYLES.iterator();
        while (it.hasNext()) {
            styles.add(new ReplaceEffect(it.next()));
        }
        return styles;
    }

    public int hashCode() {
        return this.replacement.hashCode();
    }

    public String generate(String input) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char letter = input.charAt(i);
            int index = NORMAL.indexOf(letter);
            result.append(index != -1 ? this.replacement.charAt(index) : letter);
        }
        return result.toString();
    }
}
