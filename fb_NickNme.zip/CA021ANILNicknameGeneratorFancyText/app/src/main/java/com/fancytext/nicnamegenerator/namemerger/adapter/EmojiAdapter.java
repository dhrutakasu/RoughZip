package com.fancytext.nicnamegenerator.namemerger.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.utils.ItemClickListner;

import java.util.ArrayList;

public class EmojiAdapter extends RecyclerView.Adapter<EmojiAdapter.ViewHolder> {
    Context context;
    ArrayList<Integer> icon;
    ArrayList<String> logos;
    ItemClickListner itemClickListner;
    final int AdsType = 0, Datatype = 1;

    public EmojiAdapter(Context context, ArrayList<Integer> icon, ArrayList<String> logos, ItemClickListner itemClickListner) {
        this.context = context;
        this.icon = icon;
        this.logos = logos;
        this.itemClickListner = itemClickListner;
    }

    @Override
    public int getItemViewType(int position) {
        if (logos.get( position ) == null) {
            return AdsType;
        }
        return Datatype;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
/*        View view= LayoutInflater.from(  context).inflate( R.layout.list_item_emotion_gridview,parent,false );
        return new ViewHolder( view );*/
        View view;
        switch (viewType) {
            case AdsType:
                view = LayoutInflater.from( context ).inflate( R.layout.native_ad_normal_small, parent, false );
                break;
            default:
                view = LayoutInflater.from( context ).inflate( R.layout.list_item_emotion_gridview, parent, false );
        }
        return new ViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

   /*     if (position % 10 == 0) {
            holder.ad.setVisibility(View.VISIBLE);
            MiniNativeAd.getInstance((Activity) context).showListNative(holder.adLayout, holder.adText);
        } else {
            holder.ad.setVisibility(View.GONE);
        }*/

        if (getItemViewType( position ) == AdsType) {
            BigNat.getInstance( (Activity) context ).showListNativeAds( holder.nativeAd, holder.adSpace );
        } else {
            holder.image.setImageDrawable(context.getDrawable(icon.get(position)));
            holder.name.setText(logos.get(position));
            holder.emoji.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    itemClickListner.onclick(position);
                /*    InterAd.getInstance( (Activity) context,() -> {
                        Intent intent = new Intent(context, EmotionsActivity.class);
                        intent.putExtra("image", logos.get(position));
                        intent.putExtra("P", position);
                        context.startActivity(intent);
                    }).show();*/

                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return logos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name;
        LinearLayout emoji;
        TextView adSpace;
        FrameLayout nativeAd;

        public ViewHolder(@NonNull View itemView) {
            super( itemView );
            image = itemView.findViewById( R.id.image );
            name = itemView.findViewById( R.id.name );
            emoji = itemView.findViewById( R.id.emoji );
            this.adSpace = (TextView) itemView.findViewById( R.id.ad_space );
            this.nativeAd = (FrameLayout) itemView.findViewById( R.id.native_ad );

        }
    }


}
