package com.fancytext.nicnamegenerator.namemerger.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.utils.BottomSheet;
import com.fancytext.nicnamegenerator.namemerger.utils.CopyHandler;
import com.fancytext.nicnamegenerator.namemerger.utils.NumStyle;

public class NumberAdapter extends RecyclerView.Adapter<NumberAdapter.ViewHolder> {
    /* access modifiers changed from: private */
    public Context context;
    private String name;
    String[][] number_style_arr;
    private String[] numberarr;
    int type;
    int value;

    public NumberAdapter(Context context2, String[] strArr, String[][] strArr2, String str, int i) {
        this.context = context2;
        this.numberarr = strArr;
        this.number_style_arr = strArr2;
        this.name = str;
        this.type = i;
    }

    public void setName(String str, int i) {
        this.name = str;
        this.type = i;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from( context ).inflate( R.layout.list_item_number,parent,false );
        return  new ViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

  /*      if (position % 10 == 0) {
            holder.ad.setVisibility(View.VISIBLE);
            BigNat.getInstance((Activity) context).showListNativeAds(holder.adLayout, holder.adText);
        } else {
            holder.ad.setVisibility(View.GONE);
        }*/

        holder.number.setText(String.valueOf(position + 1));
        this.value = position;
        final CopyHandler copyHandler = new CopyHandler(this.context);
        if (this.name.equalsIgnoreCase(" ")) {
            holder.result_numberstylish.setText(StyleMaker("0123456789".toLowerCase().toCharArray(), NumStyle.numberStyle[position]));
            StringBuilder sb = new StringBuilder();
            sb.append(position + 1);
            sb.append("");
        } else if (!this.name.isEmpty()) {
            holder.result_numberstylish.setText(StyleMaker(this.name.toLowerCase().toCharArray(), NumStyle.numberStyle[position]));
            StringBuilder sb2 = new StringBuilder();
            sb2.append(position + 1);
            sb2.append("");
        }
        final String data = StyleMaker(this.name.toLowerCase().toCharArray(), NumStyle.numberStyle[position]);
        holder.share_number.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copyHandler.Share(data);
            }
        });
        holder.copy_number.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                copyHandler.copy(data);
            }
        });
        holder.layout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new BottomSheet().styleBottom(NumberAdapter.this.context, data);
            }
        });
    }



    public int getItemCount() {
        return this.numberarr.length;
    }

    public long getItemId(int i) {
        return Long.parseLong(this.numberarr[i]);
    }

    private String StyleMaker(char[] cArr, String[] strArr) {
        StringBuilder stringBuffer = new StringBuilder();
        for (char c : cArr) {
            if (c - '0' >= 0 && c - '9' <= 10) {
                stringBuffer.append(strArr[c - '0']);
            }
        }
        return stringBuffer.toString();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout ad;
        FrameLayout adLayout;
        ImageView copy_number;
        LinearLayout layout = ((LinearLayout) this.itemView.findViewById(R.id.linearclick));
        TextView number,adText;
        TextView result_numberstylish;
        ImageView share_number;
        public ViewHolder(@NonNull View itemView) {
            super( itemView );
            this.result_numberstylish = (TextView) itemView.findViewById(R.id.textView);
            this.number = (TextView) itemView.findViewById(R.id.txt_number);
            this.share_number = (ImageView) itemView.findViewById(R.id.share);
            this.copy_number = (ImageView) itemView.findViewById(R.id.Copy_stylish);
         /*   this.ad=(LinearLayout) itemView.findViewById( R.id.ads );
            this.adText=(TextView) itemView.findViewById( R.id.ad_space );
            this.adLayout=(FrameLayout) itemView.findViewById( R.id.native_ad );*/
        }

    }
}
