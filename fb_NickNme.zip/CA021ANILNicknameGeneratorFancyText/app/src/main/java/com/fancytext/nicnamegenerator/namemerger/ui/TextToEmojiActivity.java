package com.fancytext.nicnamegenerator.namemerger.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;

import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityTextToEmojiBinding;
import com.fancytext.nicnamegenerator.namemerger.utils.CopyHandler;

import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;

public class TextToEmojiActivity extends AppCompatActivity {
    ActivityTextToEmojiBinding binding;
    public int num;
    public String string;
    public String quo;
    public boolean aBoolean;
    public static final String TAG = "NameTextActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTextToEmojiBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        BigNat.getInstance(this).show();

        binding.appbar.title.setText("Text to Emoji");
        binding.appbar.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.Art.setOnClickListener( new View.OnClickListener() {
            public void onClick(View view) {
                TextToEmojiActivity.this.num = 0;
                string = binding.inputEditText.getText().toString();
                if (string.isEmpty()) {
                    return;
                }
//                binding.textTV.setText( ".\n" );
                for (char c : string.toCharArray()) {
                    num++;
                    quo = "";
                    if (aBoolean) {
                        aBoolean = false;
                    } else {
                        if (c == '?') {
                            try {
                                InputStream open = getAssets().open( "ques.txt" );
                                byte[] bArr = new byte[open.available()];
                                open.read( bArr );
                                open.close();
                                TextToEmojiActivity.this.quo = new String( bArr ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );

                        }
                        if (c == '$') {
                            try {
                                InputStream open2 = getAssets().open( "dollar.txt" );
                                byte[] bArr2 = new byte[open2.available()];
                                open2.read( bArr2 );
                                open2.close();
                                quo = new String( bArr2 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == ',') {
                            try {
                                InputStream open3 = getAssets().open( "comma.txt" );
                                byte[] bArr22 = new byte[open3.available()];
                                open3.read( bArr22 );
                                open3.close();
                                quo = new String( bArr22 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e22) {
                                e22.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '=') {
                            try {
                                InputStream open4 = getAssets().open( "equals.txt" );
                                byte[] bArr23 = new byte[open4.available()];
                                open4.read( bArr23 );
                                open4.close();
                                quo = new String( bArr23 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e23) {
                                e23.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '!') {
                            try {
                                InputStream open5 = getAssets().open( "exclamation.txt" );
                                byte[] bArr24 = new byte[open5.available()];
                                open5.read( bArr24 );
                                open5.close();
                                quo = new String( bArr24 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e24) {
                                e24.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '-') {
                            try {
                                InputStream open6 = getAssets().open( "minus.txt" );
                                byte[] bArr25 = new byte[open6.available()];
                                open6.read( bArr25 );
                                open6.close();
                                quo = new String( bArr25 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e25) {
                                e25.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '\"') {
                            try {
                                InputStream open7 = getAssets().open( "doublequotes.txt" );
                                byte[] bArr26 = new byte[open7.available()];
                                open7.read( bArr26 );
                                open7.close();
                                quo = new String( bArr26 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e26) {
                                e26.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == ':') {
                            try {
                                InputStream open8 = getAssets().open( "colon.txt" );
                                byte[] bArr27 = new byte[open8.available()];
                                open8.read( bArr27 );
                                open8.close();
                                quo = new String( bArr27 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e27) {
                                e27.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '+') {
                            try {
                                InputStream open9 = getAssets().open( "plus.txt" );
                                byte[] bArr28 = new byte[open9.available()];
                                open9.read( bArr28 );
                                open9.close();
                                quo = new String( bArr28 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e28) {
                                e28.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '_') {
                            try {
                                InputStream open10 = getAssets().open( "underscore.txt" );
                                byte[] bArr29 = new byte[open10.available()];
                                open10.read( bArr29 );
                                open10.close();
                                quo = new String( bArr29 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e29) {
                                e29.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '*') {
                            try {
                                InputStream open11 = getAssets().open( "star.txt" );
                                byte[] bArr210 = new byte[open11.available()];
                                open11.read( bArr210 );
                                open11.close();
                                quo = new String( bArr210 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e210) {
                                e210.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '#') {
                            try {
                                InputStream open12 = getAssets().open( "hash.txt" );
                                byte[] bArr211 = new byte[open12.available()];
                                open12.read( bArr211 );
                                open12.close();
                                quo = new String( bArr211 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e211) {
                                e211.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '%') {
                            try {
                                InputStream open13 = getAssets().open( "modulo.txt" );
                                byte[] bArr212 = new byte[open13.available()];
                                open13.read( bArr212 );
                                open13.close();
                                quo = new String( bArr212 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e212) {
                                e212.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        }
                        if (c == '&') {
                            try {
                                InputStream open14 = getAssets().open( "ampersand.txt" );
                                byte[] bArr213 = new byte[open14.available()];
                                open14.read( bArr213 );
                                open14.close();
                                quo = new String( bArr213 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e213) {
                                e213.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        } else if (c == ((char) (c & '_')) || Character.isDigit( c )) {
                            try {
                                InputStream open15 = getAssets().open( c + ".txt" );
                                byte[] bArr3 = new byte[open15.available()];
                                open15.read( bArr3 );
                                open15.close();
                                quo = new String( bArr3 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e3) {
                                e3.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                            quo = "";
                            aBoolean = true;
                        } else {
                            try {
                                InputStream open16 = getAssets().open( "sml" + c + ".txt" );
                                byte[] bArr4 = new byte[open16.available()];
                                open16.read( bArr4 );
                                open16.close();
                                quo = new String( bArr4 ).replaceAll( "[*]", binding.pickedemo.getText().toString() );
                                Log.e( TAG, "quo: " + quo );
                                Log.e( TAG, "quo: " + quo );
                            } catch (IOException e4) {
                                e4.printStackTrace();
                            }
                            binding.textTV.append( quo + "\n\n" );
                        }
                    }
                }
            }
        } );

        binding.setEmo.setOnClickListener( new View.OnClickListener() {
            public void onClick(View view) {
                String obj = binding.pickemo.getText().toString();
                if (obj.isEmpty() || obj.matches( "[\\x00-\\x7F]+" )) {
                } else {
                    binding.pickedemo.setText( obj );
                }
            }
        } );

        binding.close22.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                int length = binding.inputEditText.getText().length();
                if (length > 0) {
                    binding.inputEditText.getText().delete( length - 1, length );
                }
            }
        } );

        binding.close22.setOnLongClickListener( new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                binding.inputEditText.getText().clear();
                return false;
            }
        } );

        binding.shareemo.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CopyHandler copyHandler = new CopyHandler( TextToEmojiActivity.this );
                String data = binding.textTV.getText().toString();
                copyHandler.Share( data );
            }
        } );

        binding.copyemo.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CopyHandler copyHandler = new CopyHandler( TextToEmojiActivity.this );
                String data = binding.textTV.getText().toString();
                copyHandler.copy( data );
            }
        } );
    }

    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}