package com.fancytext.nicnamegenerator.namemerger.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.model.EmotiModel;
import com.fancytext.nicnamegenerator.namemerger.utils.BottomSheet;
import com.fancytext.nicnamegenerator.namemerger.utils.CopyHandler;
import com.fancytext.nicnamegenerator.namemerger.utils.SharedPreference;

import java.util.List;


public class EmoticonsAdapter extends RecyclerView.Adapter<EmoticonsAdapter.MyViewHolder> {
    /* access modifiers changed from: private */
    public Activity context;
    List<EmotiModel> emotiModels;
    SharedPreference sharedPreference = new SharedPreference();

    public EmoticonsAdapter(List<EmotiModel> emotiModels2, Activity context2) {
        this.emotiModels = emotiModels2;
        this.context = context2;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder( LayoutInflater.from( this.context ).inflate( R.layout.list_item_emotion, parent, false ) );
    }


    public void onBindViewHolder(final MyViewHolder holder, int position) {


        EmotiModel emotiModel = this.emotiModels.get( position );
  /*      if (position % 10 == 0) {
            holder.ad.setVisibility(View.VISIBLE);
            BigNat.getInstance((Activity) context).showListNativeAds(holder.adLayout, holder.adText);
        } else {
            holder.ad.setVisibility(View.GONE);
        }*/

        holder.emoticons.setText( emotiModel.getName() );
        holder.emoticons.setSelected( true );
        holder.number.setText( String.valueOf( position + 1 ) );
        final CopyHandler copyHandler = new CopyHandler( this.context );
        final String text = holder.emoticons.getText().toString();
        holder.copy.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                copyHandler.copy( text );
            }
        } );
        holder.share.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                copyHandler.Share( text );
            }
        } );
        holder.cardView.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                new BottomSheet().styleBottom( EmoticonsAdapter.this.context, text );
            }
        } );


    }

    public int getItemCount() {
        return this.emotiModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageButton copy;
        TextView emoticons;
        TextView number, adText;
        ImageButton share;

        LinearLayout ad;
        FrameLayout adLayout;

        public MyViewHolder(View itemView) {
            super( itemView );
            this.number = (TextView) itemView.findViewById( R.id.numtxt );
            this.copy = (ImageButton) itemView.findViewById( R.id.copy2 );
            this.share = (ImageButton) itemView.findViewById( R.id.btn_share2 );
            this.emoticons = (TextView) itemView.findViewById( R.id.emoti );
            this.cardView = (CardView) itemView.findViewById( R.id.root1 );
 /*           this.ad=(LinearLayout) itemView.findViewById( R.id.ads );
            this.adText=(TextView) itemView.findViewById( R.id.ad_space );
            this.adLayout=(FrameLayout) itemView.findViewById( R.id.native_ad );*/
        }
    }

    public boolean checkFavoriteItem(EmotiModel checkEmoti) {
        List<EmotiModel> favorites = this.sharedPreference.getFavorites( this.context );
        if (favorites == null) {
            return false;
        }
        for (EmotiModel emotiModel : favorites) {
            if (emotiModel.equals( checkEmoti )) {
                return true;
            }
        }
        return false;
    }

    public void add(EmotiModel emotiModel) {
        this.emotiModels.add( emotiModel );
        notifyDataSetChanged();
    }

    public void remove(EmotiModel emotiModel) {
        this.emotiModels.remove( emotiModel );
        notifyDataSetChanged();
    }
}
