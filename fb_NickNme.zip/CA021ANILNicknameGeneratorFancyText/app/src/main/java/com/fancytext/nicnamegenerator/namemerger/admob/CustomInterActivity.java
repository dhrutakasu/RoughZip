package com.fancytext.nicnamegenerator.namemerger.admob;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityCustomInterBinding;
import com.preference.PowerPreference;

public class CustomInterActivity extends AppCompatActivity {
    ActivityCustomInterBinding binding;    AllManager adManage;
    CustomAd customAd;
    public boolean isInCustom = false;
    public String nativeBtn = "#FF363636";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityCustomInterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        isInCustom = PowerPreference.getDefaultFile().getBoolean(AllManager.IS_IN_CUSTOM, isInCustom);
        nativeBtn = PowerPreference.getDefaultFile().getString(AllManager.N_BTN_COLOR, nativeBtn);

        adManage = new AllManager(this);
        if (isInCustom) {
            if (PowerPreference.getDefaultFile().getInt("qCount", 0) >= 5) {
                PowerPreference.getDefaultFile().putInt("qCount", 0);

            }

            Glide.with(this).load(AllManager.adsQurekaInters[PowerPreference.getDefaultFile().getInt("qCount", 0)]).into(binding.qurekaAds1);
            Glide.with(this).load(AllManager.adsQurekaInters[PowerPreference.getDefaultFile().getInt("qCount", 0)]).into(binding.qurekaAds);
            Glide.with(this).asGif().load(AllManager.adsQurekaGifInters[PowerPreference.getDefaultFile().getInt("qCount", 0)]).into(binding.gifInterRound);

            binding.qurekaAdsPlay.getBackground().setTint( Color.parseColor(nativeBtn));

            binding.qurekaAdLayout.setOnClickListener(view -> AllManager.gotoAds(CustomInterActivity.this, PowerPreference.getDefaultFile().getString(AllManager.Q_URL)));

            int top = PowerPreference.getDefaultFile().getInt("qCount", 0) + 1;
            PowerPreference.getDefaultFile().putInt("qCount", top == 5 ? 0 : top);


        } else {
            customAd = adManage.getCustomAd(AllManager.AD_TYPE_INTER);

            Glide.with(this).load(AllManager.BASE_URL + customAd.media_image).into(binding.qurekaAds1);
            Glide.with(this).load(AllManager.BASE_URL + customAd.media_image).into(binding.qurekaAds);
            Glide.with(this).load(AllManager.BASE_URL + customAd.logo).into(binding.gifInterRound);
            binding.tvTextAdName.setText(customAd.title);
            binding.tvTextAdDesc.setText(customAd.description);
            binding.btnPlay.setText(customAd.btn_text);
            binding.btnPlay.setTextColor(Color.parseColor(customAd.btn_text_color));
            binding.qurekaAdsPlay.getBackground().setTint(Color.parseColor(customAd.btn_color));

            binding.qurekaAdLayout.setOnClickListener(view -> AllManager.gotoAds(CustomInterActivity.this, customAd.url));

        }

        binding.qurekaAdsClose.setOnClickListener(v -> finish());


    }
}