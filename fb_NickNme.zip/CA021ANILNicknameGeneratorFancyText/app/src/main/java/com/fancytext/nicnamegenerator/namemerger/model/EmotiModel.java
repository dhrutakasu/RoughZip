package com.fancytext.nicnamegenerator.namemerger.model;

public class EmotiModel {

    /* renamed from: id */
    private int f130id;
    private String name;

    public EmotiModel() {
    }

    public EmotiModel(int id, String name2) {
        this.f130id = id;
        this.name = name2;
    }

    public int getId() {
        return this.f130id;
    }

    public void setId(int id) {
        this.f130id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name2) {
        this.name = name2;
    }

    public int hashCode() {
        return (1 * 31) + this.f130id;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass() && this.f130id == ((EmotiModel) obj).f130id) {
            return true;
        }
        return false;
    }

    public String toString() {
        return "Product [id=" + this.f130id + ", name=" + this.name + "]";
    }
}
