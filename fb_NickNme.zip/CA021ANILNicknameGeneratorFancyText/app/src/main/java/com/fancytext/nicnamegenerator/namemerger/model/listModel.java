package com.fancytext.nicnamegenerator.namemerger.model;

public class listModel {
    private String _name;

    public listModel(String str) {
        this._name = str;
    }

    public String get_name() {
        return this._name;
    }

    public void set_name(String str) {
        this._name = str;
    }
}
