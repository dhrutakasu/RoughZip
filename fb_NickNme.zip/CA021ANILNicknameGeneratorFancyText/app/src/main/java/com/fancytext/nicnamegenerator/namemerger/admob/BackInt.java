package com.fancytext.nicnamegenerator.namemerger.admob;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.fancytext.nicnamegenerator.namemerger.utils.LoadingDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.preference.PowerPreference;

public class BackInt {

    Activity activity;

    public static InterstitialAd gInterAd;
    public static com.facebook.ads.InterstitialAd fInterAd;
    public static final int GOOGLE = 0;
    public static final int FB = 1;

    //TODO Manage OR Remove below Object OR variables

    public static int adPriority = 0;
    public static String gInterAdId = "";
    public static String fInterAdId = "";
    public static int refreshTime = 0;
    public static int backCount = 3;
    public static int appBackCount = 3;
    public static int backLoaderTimer = 0;
    public static boolean isAdOn = false;
    public static boolean isBackOn = false;
    public static AdListener adListener;

    LoadingDialog loadingDialog;
    public static int count = 0;

    public boolean isCustomOn = false;


    public BackInt(Activity activity) {
        this.activity = activity;
        getPowerPrefData();
    }

    private void getPowerPrefData() {
        adPriority = PowerPreference.getDefaultFile().getInt( AllManager.PRIORITY, GOOGLE);
        gInterAdId = PowerPreference.getDefaultFile().getString( AllManager.G_INTER_ID);
        fInterAdId = PowerPreference.getDefaultFile().getString( AllManager.F_INTER_ID);
        refreshTime = PowerPreference.getDefaultFile().getInt( AllManager.REFRESH_TIMER, refreshTime);
        isAdOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_ON, isAdOn);
        isBackOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_BACK_IN_ON, isBackOn);
        backCount = PowerPreference.getDefaultFile().getInt( AllManager.BACK_IN_COUNT, backCount);
        backLoaderTimer = PowerPreference.getDefaultFile().getInt( AllManager.INT_LOADER_SEC, backLoaderTimer);
        isCustomOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_CUSTOM_ON, isCustomOn);
        loadingDialog = new LoadingDialog(activity);
    }


    public static BackInt getInstance(Activity activity) {
        return new BackInt(activity);
    }

    public BackInt(Activity activity, AdListener adListener) {
        this.activity = activity;
        this.adListener = adListener;
        getPowerPrefData();
    }

    public static BackInt getInstance(Activity activity, AdListener adListener) {
        return new BackInt(activity, adListener);
    }

    public void load() {
        if (!isAdOn || !isBackOn) {
            return;
        }
        switch (adPriority) {
            case GOOGLE: {
                loadGoogleInter();
                break;
            }
            case FB: {
                loadFBInter();
                break;
            }
        }
    }

    private void loadGoogleInter() {
        Log.e(TAG, "BackInt->loadGoogleInter->amInterAdId: " + gInterAdId);
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, gInterAdId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                super.onAdLoaded(interstitialAd);
                gInterAd = interstitialAd;

                count++;

                gInterAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        reloadAd();
                        if (adListener != null) {
                            adListener.onAdClosed();
                        }
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                        gInterAd = null;
                        if (adPriority == GOOGLE) {
                            showFBInter();
                        } else {
                            Log.e(TAG, "onAdFailedToShowFullScreenContent: reload & showCustomInter");
                            reloadAd();
                            showCustomInter();
                        }

                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        Log.e(TAG, "onAdShowedFullScreenContent: ");
                        gInterAd = null;
                        if (adListener != null) {
                            adListener.onAdClosed();
                        }
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                gInterAd = null;
                if (adPriority == GOOGLE) {
                    Log.e(TAG, "onAdFailedToLoad: loadFBInter");
                    loadFBInter();
                } else {
                    //TODO - We have think about it.
                    // What if Google Request fail and ad Priority is FB
                }
            }
        });
    }


    private void loadFBInter() {
        Log.e(TAG, "BackInt->loadGoogleInter->fbInterAdId: " + fInterAdId);
        fInterAd = new com.facebook.ads.InterstitialAd(activity, fInterAdId);
        fInterAd.loadAd(fInterAd.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e(TAG, "onInterstitialDismissed: reloadAd");
                reloadAd();
                if (adListener != null) {
                    Log.e(TAG, "FB->onInterstitialDismissed: trigger close listener");
                    adListener.onAdClosed();
                }
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                fInterAd = null;
                if (adPriority == FB) {
                    Log.e(TAG, "onError: loadGoogleInter");
                    loadGoogleInter();
                } else {
                    //TODO - We have think about it.
                    // What if FB Request fail and ad Priority is Google
                }

            }

            @Override
            public void onAdLoaded(Ad ad) {
                count++;
                Log.e(TAG, "Facebook Inter Loaded: " + count);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        }).build());
    }


    public void show() {
        if (!isAdOn || !isBackOn) {
            if (adListener != null) {
                adListener.onAdClosed();
            }
            return;
        }

        appBackCount = PowerPreference.getDefaultFile().getInt(APP_BACK_INTER_COUNT, 0);
        if (appBackCount % backCount == 0) {
            if (adPriority == GOOGLE) {
                showGoogleInter();
            } else {
                showFBInter();
            }
        } else {
            if (adListener != null) {
                adListener.onAdClosed();
            }
        }
        updateAppInterCount();
    }

    public static final String APP_BACK_INTER_COUNT = "app_back_inter_count";

    private void updateAppInterCount() {
        appBackCount = PowerPreference.getDefaultFile().getInt(APP_BACK_INTER_COUNT, 0);
        appBackCount++;
        PowerPreference.getDefaultFile().setInt(APP_BACK_INTER_COUNT, appBackCount);
    }

    private void showGoogleInter() {
        Log.e(TAG, "BackInt->showGoogleInter->start");
        Log.e(TAG, "BackInt->showGoogleInter->appInterCount: " + appBackCount);
        if (gInterAd != null) {
            Log.e(TAG, "BackInt->showGoogleInter->isNotNull");
            if (backLoaderTimer > 0) {
                Log.e(TAG, "BackInt->showGoogleInter->showDialog");
                loadingDialog.show();
                new Handler().postDelayed(() -> {
                    gInterAd.show(activity);
                    loadingDialog.dismiss();
                }, backLoaderTimer * 1000L);
            } else {
                gInterAd.show(activity);
            }
            Log.e(TAG, "Google Inter Show: " + count);
        } else {
            Log.e(TAG, "BackInt->showGoogleInter->isNull ");
            if (adPriority == GOOGLE) {
                showFBInter();
            } else {
                reloadAd();
                showCustomInter();
            }
        }
    }

    private void showFBInter() {
        if (fInterAd != null && fInterAd.isAdLoaded()) {
            if (backLoaderTimer > 0) {
                loadingDialog.show();
                new Handler().postDelayed(() -> {
                    loadingDialog.dismiss();
                    fInterAd.show();
                }, backLoaderTimer * 1000L);
            } else {
                fInterAd.show();
            }
            Log.e(TAG, "FB Inter Show: " + count);
        } else {
            if (adPriority == FB) {
                showGoogleInter();
            } else {
                reloadAd();
                showCustomInter();
            }
        }
    }

    private void reloadAd() {
        new Handler().postDelayed( BackInt.this::load, refreshTime * 1000L);
    }

    public interface AdListener {
        void onAdClosed();
    }

    private void showCustomInter() {
        if (!isCustomOn) {
            adListener.onAdClosed();
            return;
        }
        //TODO Show Custom Inter

        if (backLoaderTimer > 0) {
            Log.e(TAG, "BackInt->showGoogleInter->showDialog");
            loadingDialog.show();
            new Handler().postDelayed(() -> {
                adListener.onAdClosed();
                activity.startActivity(new Intent(activity, CustomInterActivity.class));
                loadingDialog.dismiss();
            }, backLoaderTimer * 1000L);
        } else {
            adListener.onAdClosed();
            activity.startActivity(new Intent(activity, CustomInterActivity.class));
        }
    }
}
