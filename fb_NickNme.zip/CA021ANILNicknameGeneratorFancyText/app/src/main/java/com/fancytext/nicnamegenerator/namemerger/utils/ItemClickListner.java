package com.fancytext.nicnamegenerator.namemerger.utils;

public interface ItemClickListner {
    public void onclick(int position);
}
