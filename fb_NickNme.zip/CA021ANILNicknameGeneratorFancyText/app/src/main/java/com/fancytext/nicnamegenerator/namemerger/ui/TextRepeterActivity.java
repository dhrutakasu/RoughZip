package com.fancytext.nicnamegenerator.namemerger.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;

import com.fancytext.nicnamegenerator.namemerger.admob.BackInt;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;
import com.fancytext.nicnamegenerator.namemerger.databinding.ActivityTextRepeterBinding;
import com.fancytext.nicnamegenerator.namemerger.utils.CopyHandler;

public class TextRepeterActivity extends AppCompatActivity {
    ActivityTextRepeterBinding binding;
    int number;
    String msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTextRepeterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
        BigNat.getInstance(this).show();

        binding.appbar.title.setText("Text Repeater");
        binding.appbar.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        binding.close22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int length = binding.msg.getText().length();
                if (length > 0) {
                    binding.msg.getText().delete(length - 1, length);
                }
            }
        });

        binding.close22.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                binding.msg.getText().clear();
                return false;
            }
        });

        binding.shareemo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CopyHandler copyHandler = new CopyHandler(TextRepeterActivity.this);
                String data = binding.textTV.getText().toString();
                copyHandler.Share(data);
            }
        });

        binding.copyemo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CopyHandler copyHandler = new CopyHandler(TextRepeterActivity.this);
                String data = binding.textTV.getText().toString();
                copyHandler.copy(data);
            }
        });


        binding.repeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                msg = binding.msg.getText().toString();
                try {
                    number = Integer.parseInt(binding.number.getText().toString());
                } catch (NumberFormatException e) {
                }

                StringBuilder repeatedTextBuilder = new StringBuilder();
                if (!msg.isEmpty() && !binding.number.getText().toString().isEmpty()) {

                    for (int i = 0; i < number; i++) {
                        repeatedTextBuilder.append(msg + "\n");
                    }

                    binding.textTV.setText(repeatedTextBuilder.toString());
                } else {
                    Toast.makeText(TextRepeterActivity.this, "Enter message and number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        BackInt.getInstance(this, this::finish).show();
    }
}