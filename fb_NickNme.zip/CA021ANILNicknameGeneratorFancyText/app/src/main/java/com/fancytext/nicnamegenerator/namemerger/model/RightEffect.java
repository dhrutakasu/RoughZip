package com.fancytext.nicnamegenerator.namemerger.model;


import com.fancytext.nicnamegenerator.namemerger.Interface.Style;

public class RightEffect implements Style {
    private String character;

    public RightEffect(String text) {
        this.character = text;
    }

    public String generate(String input) {
        try {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < input.length(); i++) {
                if (input.charAt(i) == ' ') {
                    result.append(" ");
                } else {
                    result.append(input.charAt(i));
                    result.append(this.character);
                }
            }
            return result.toString();
        } catch (OutOfMemoryError e) {
            return "";
        }
    }

    public int hashCode() {
        return this.character.hashCode();
    }
}
