package com.fancytext.nicnamegenerator.namemerger.admob;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.fancytext.nicnamegenerator.namemerger.utils.LoadingDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.preference.PowerPreference;

public class PageChange {

    private static final String TAG = "PageChange";
    Activity activity;

    public static InterstitialAd gInterAd;
    public static com.facebook.ads.InterstitialAd fInterAd;
    public static final int GOOGLE = 0;
    public static final int FB = 1;

    //TODO Manage OR Remove below Object OR variables

    public static int adPriority = 0;
    public static String gInterAdId = "";
    public static String fInterAdId = "";
    public static int refreshTime = 0;
    public static int interCount = 3;
    public static int appInterCount = 3;
    public static int interLoaderTimer = 0;
    public static boolean isOn = false;
    public static AdListener adListener;

    LoadingDialog loadingDialog;
    public static int count = 0;

    public boolean isCustomOn = false;

    public PageChange(Activity activity) {
        this.activity = activity;
        getPowerPrefData();
    }

    private void getPowerPrefData() {
        adPriority = PowerPreference.getDefaultFile().getInt( AllManager.PRIORITY, GOOGLE);
        gInterAdId = PowerPreference.getDefaultFile().getString( AllManager.G_INTER_ID);
        fInterAdId = PowerPreference.getDefaultFile().getString( AllManager.F_INTER_ID);
        refreshTime = PowerPreference.getDefaultFile().getInt( AllManager.REFRESH_TIMER, refreshTime);
        isOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_ON, isOn);
        interCount = PowerPreference.getDefaultFile().getInt( AllManager.INT_COUNT, interCount);
        interLoaderTimer = PowerPreference.getDefaultFile().getInt( AllManager.INT_LOADER_SEC, interLoaderTimer);
        isCustomOn = PowerPreference.getDefaultFile().getBoolean( AllManager.IS_CUSTOM_ON, isCustomOn);
        loadingDialog = new LoadingDialog(activity);
    }


    public static PageChange getInstance(Activity activity) {
        return new PageChange(activity);
    }

    public PageChange(Activity activity, AdListener adListener) {
        this.activity = activity;
        this.adListener = adListener;
        getPowerPrefData();
    }

    public static PageChange getInstance(Activity activity, AdListener adListener) {
        return new PageChange(activity, adListener);
    }

    public void load() {
        if (!isOn) {
            return;
        }
        switch (adPriority) {
            case GOOGLE: {
                loadGoogleInter();
                break;
            }
            case FB: {
                loadFBInter();
                break;
            }
        }
    }

    private void loadGoogleInter() {
        Log.e(TAG, "PageChange->loadGoogleInter->amInterAdId: " + gInterAdId);
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, gInterAdId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                super.onAdLoaded(interstitialAd);
                gInterAd = interstitialAd;

                count++;
                Log.e(TAG, "PageChange->Google->Count: " + count);
                Log.e(TAG, "PageChange->Google->isNull: " + (gInterAd == null));

                gInterAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        Log.e(TAG, "onAdDismissedFullScreenContent: reloadAd");
                        reloadAd();
                        if (adListener != null) {
                            Log.e(TAG, "onAdDismissedFullScreenContent: trigger close listener");
                            adListener.onAdClosed();
                        }
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                        gInterAd = null;
                        if (adPriority == GOOGLE) {
                            Log.e(TAG, "onAdFailedToShowFullScreenContent: showFBInter");
                            showFBInter();
                        } else {
                            Log.e(TAG, "onAdFailedToShowFullScreenContent: reload & showCustomInter");
                            reloadAd();
                            showCustomInter();
                        }

                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        Log.e(TAG, "onAdShowedFullScreenContent: ");
                        gInterAd = null;
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                gInterAd = null;
                if (adPriority == GOOGLE) {
                    Log.e(TAG, "onAdFailedToLoad: loadFBInter");
                    loadFBInter();
                } else {
                    //TODO - We have think about it.
                    // What if Google Request fail and ad Priority is FB
                }
            }
        });
    }


    private void loadFBInter() {
        Log.e(TAG, "PageChange->loadGoogleInter->fbInterAdId: " + fInterAdId);
        fInterAd = new com.facebook.ads.InterstitialAd(activity, fInterAdId);
        fInterAd.loadAd(fInterAd.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                Log.e(TAG, "onInterstitialDismissed: reloadAd");
                reloadAd();
                if (adListener != null) {
                    Log.e(TAG, "FB->onInterstitialDismissed: trigger close listener");
                    adListener.onAdClosed();
                }
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                fInterAd = null;
                if (adPriority == FB) {
                    Log.e(TAG, "onError: loadGoogleInter");
                    loadGoogleInter();
                } else {
                    //TODO - We have think about it.
                    // What if FB Request fail and ad Priority is Google
                }

            }

            @Override
            public void onAdLoaded(Ad ad) {

                count++;
                Log.e(TAG, "Facebook Inter Loaded: " + count);
            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        }).build());
    }


    public void show() {
        if (!isOn) {
            if (adListener != null) {
                adListener.onAdClosed();
            }
            return;
        }

        appInterCount = PowerPreference.getDefaultFile().getInt(APP_INTER_COUNT, 0);
        if (appInterCount % interCount == 0) {
            if (adPriority == GOOGLE) {
                showGoogleInter();
            } else {
                showFBInter();
            }
        } else {
            if (adListener != null) {
                adListener.onAdClosed();
            }
        }
        updateAppInterCount();
    }

    public static final String APP_INTER_COUNT = "app_inter_count";

    private void updateAppInterCount() {
        appInterCount = PowerPreference.getDefaultFile().getInt(APP_INTER_COUNT, 0);
        appInterCount++;
        PowerPreference.getDefaultFile().setInt(APP_INTER_COUNT, appInterCount);
    }

    private void showGoogleInter() {
        Log.e(TAG, "PageChange->showGoogleInter->start");
        Log.e(TAG, "PageChange->showGoogleInter->appInterCount: " + appInterCount);
        if (gInterAd != null) {
            Log.e(TAG, "PageChange->showGoogleInter->isNotNull");
            if (interLoaderTimer > 0) {
                Log.e(TAG, "PageChange->showGoogleInter->showDialog");
                loadingDialog.show();
                new Handler().postDelayed(() -> {
                    loadingDialog.dismiss();
                    gInterAd.show(activity);
                }, interLoaderTimer * 1000L);
            } else {
                gInterAd.show(activity);
            }
            Log.e(TAG, "Google Inter Show: " + count);
        } else {
            Log.e(TAG, "PageChange->showGoogleInter->isNull ");
            if (adPriority == GOOGLE) {
                showFBInter();
            } else {
                reloadAd();
                showCustomInter();
            }
        }
    }

    private void showFBInter() {
        if (fInterAd != null && fInterAd.isAdLoaded()) {
            if (interLoaderTimer > 0) {
                loadingDialog.show();
                new Handler().postDelayed(() -> {
                    loadingDialog.dismiss();
                    fInterAd.show();
                }, interLoaderTimer * 1000L);
            } else {
                fInterAd.show();
            }
            Log.e(TAG, "FB Inter Show: " + count);
        } else {
            if (adPriority == FB) {
                showGoogleInter();
            } else {
                reloadAd();
                showCustomInter();
            }
        }
    }

    private void reloadAd() {
        new Handler().postDelayed( PageChange.this::load, refreshTime * 1000L);
    }

    public interface AdListener {
        void onAdClosed();
    }

    private void showCustomInter() {
        if (!isCustomOn) {
            adListener.onAdClosed();
            return;
        }

        if (interLoaderTimer > 0) {
            Log.e(TAG, "PageChange->showGoogleInter->showDialog");
            loadingDialog.show();
            new Handler().postDelayed(() -> {
                loadingDialog.dismiss();
                adListener.onAdClosed();
                activity.startActivity(new Intent(activity, CustomInterActivity.class));
            }, interLoaderTimer * 1000L);
        } else {
            adListener.onAdClosed();
            activity.startActivity(new Intent(activity, CustomInterActivity.class));
        }


        //TODO Show Custom Inter
    }
}
