package com.fancytext.nicnamegenerator.namemerger.model;


import com.fancytext.nicnamegenerator.namemerger.Interface.Style;

public class LeftRightStyle implements Style {
    private String left;
    private String right;

    public LeftRightStyle(String left2, String right2) {
        this.left = left2;
        this.right = right2;
    }

    public String generate(String text) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == ' ') {
                result.append(" ");
            } else {
                result.append(this.left);
                result.append(text.charAt(i));
                result.append(this.right);
            }
        }
        return result.toString();
    }

    public int hashCode() {
        return (this.left.hashCode() * 31) + this.right.hashCode();
    }
}
