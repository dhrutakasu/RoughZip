package com.fancytext.nicnamegenerator.namemerger.utils;

import android.app.Activity;

public class NumStyle {
    public static String[] Number = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"};
    private static Activity activity;
    public static int color;
    public static String[][] numberStyle;

    static {
        String[][] strArr = new String[15][];
        numberStyle = strArr;
        strArr[0] = new String[]{"⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"};
        strArr[1] = new String[]{"օ", "յ", "շ", "Յ", "կ", "Տ", "ճ", "Դ", "Ց", "գ"};
        strArr[2] = new String[]{"⓿", "➊", "➋", "➌", "➍", "➎", "➏", "➐", "➑", "➒"};
        strArr[3] = new String[]{"0̴", "1̴", "2̴", "3̴", "4̴", "5̴", "6̴", "7̴", "8̴", "9̴"};
        strArr[4] = new String[]{"[̲̅0̲̅]", "[̲̅1̲̅]", "[̲̅2̲̅]", "[̲̅3̲̅]", "[̲̅4̲̅]", "[̲̅5̲̅]", "[̲̅6̲̅]", "[̲̅7̲̅]", "[̲̅8̲̅]", "[̲̅9̲̅]"};
        strArr[5] = new String[]{"【0】", "【1】", "【2】", "【3】", "【4】", "【5】", "【6】", "【7】", "【8】", "【9】"};
        strArr[6] = new String[]{"『0』", "『1』", "『2』", "『3』", "『4』", "『5』", "『6』", "『7』", "『8』", "『9』"};
        strArr[7] = new String[]{"0͓̽", "1͓̽", "2͓̽", "3͓̽", "4͓̽", "5͓̽", "6͓̽", "7͓̽", "8͓̽", "9͓̽"};
        strArr[8] = new String[]{"0♥", "1♥", "2♥", "3♥", "4♥", "5♥", "6♥", "7♥", "8♥", "9♥"};
        strArr[9] = new String[]{"0✿", "1✿", "2✿", "3✿", "4✿", "5✿", "6✿", "7✿", "8✿", "9✿"};
        strArr[10] = new String[]{"0★", "1★", "2★", "3★", "4★", "5★", "6★", "7★", "8★", "9★"};
        strArr[11] = new String[]{"彡0彡", "彡1彡", "彡2彡", "彡3彡", "彡4彡", "彡5彡", "彡6彡", "彡7彡", "彡8彡", "彡9彡"};
        strArr[12] = new String[]{"⓪", "⓵", "⓶", "⓷", "⓸", "⓹", "⓺", "⓻", "⓼", "⓽"};
        strArr[13] = new String[]{"►0◄", "►1◄", "►2◄", "►3◄", "►4◄", "►5◄", "►6◄", "►7◄", "►8◄", "►9◄"};
        strArr[14] = new String[]{"♕0", "♕1", "♕2", "♕3", "♕4", "♕5", "♕6", "♕7", "♕8", "♕9"};
    }
}
