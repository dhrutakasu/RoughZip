package com.fancytext.nicnamegenerator.namemerger.model;

import com.fancytext.nicnamegenerator.namemerger.Interface.Style;

import java.util.Arrays;

public class BlueEffect implements Style {

    private static final String NORMAL = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String[] EFFECTS = new String[NORMAL.length()];

    static {
        int length = NORMAL.length();
        int step = "🇦 🇧 🇨 🇩 🇪 🇫 🇬 🇭 🇮 🇯 🇰 🇱 🇲 🇳 🇴 🇵 🇶 🇷 🇸 🇹 🇺 🇻 🇼 🇽 🇾 🇿 🇦 🇧 🇨 🇩 🇪 🇫 🇬 🇭 🇮 🇯 🇰 🇱 🇲 🇳 🇴 🇵 🇶 🇷 🇸 🇹 🇺 🇻 🇼 🇽 🇾 🇿 ".length() / length;
        for (int j = 0; j < length; j++) {
            EFFECTS[j] = "🇦 🇧 🇨 🇩 🇪 🇫 🇬 🇭 🇮 🇯 🇰 🇱 🇲 🇳 🇴 🇵 🇶 🇷 🇸 🇹 🇺 🇻 🇼 🇽 🇾 🇿 🇦 🇧 🇨 🇩 🇪 🇫 🇬 🇭 🇮 🇯 🇰 🇱 🇲 🇳 🇴 🇵 🇶 🇷 🇸 🇹 🇺 🇻 🇼 🇽 🇾 🇿 ".substring(j * step, (j + 1) * step);
        }
    }

    public String generate(String text) {
        Object obj = null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char letter = text.charAt(i);
            int index = NORMAL.indexOf(letter);

            if (index != -1) {
                try {
                    obj = EFFECTS[index];
                } catch (Exception e) {
                    result.append(letter);
                }
            } else {
                obj = Character.valueOf(letter);
            }
            result.append(obj);
        }
        return result.toString();
    }

    public int hashCode() {
        return Arrays.hashCode(EFFECTS);
    }
}
