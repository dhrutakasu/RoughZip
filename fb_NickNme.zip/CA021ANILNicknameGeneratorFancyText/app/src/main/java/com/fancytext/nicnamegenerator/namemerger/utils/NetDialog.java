package com.fancytext.nicnamegenerator.namemerger.utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;


import com.fancytext.nicnamegenerator.namemerger.R;

public class NetDialog {

    Dialog internetDialog;

    public NetDialog(Context context, InternetListener listener) {
        internetDialog = new Dialog(context);
        internetDialog.setContentView( R.layout.no_internet_connection);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(internetDialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;

        TextView tryAgainBtn = internetDialog.findViewById(R.id.btn_try_again);
        tryAgainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable(context)) {
                    internetDialog.dismiss();
                    listener.onInternetAvailable();
                } else {
                    Toast.makeText(context, "Please turn on your Internet", Toast.LENGTH_SHORT).show();
                }
            }
        });

        internetDialog.getWindow().setAttributes(lp);
        internetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        internetDialog.setCancelable(false);


        if (isNetworkAvailable(context)) {
            listener.onInternetAvailable();
        } else {
            show();
        }
    }


    public void show() {
        if (internetDialog != null) {
            internetDialog.show();
        }
    }

    public void dismiss() {
        if (internetDialog != null) {
            internetDialog.dismiss();
        }
    }

    public interface InternetListener {
        void onInternetAvailable();
    }

    public boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            return true;
        } else return false;
    }


}
