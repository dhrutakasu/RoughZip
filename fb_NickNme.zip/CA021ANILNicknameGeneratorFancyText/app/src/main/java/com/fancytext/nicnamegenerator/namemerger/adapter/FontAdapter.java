package com.fancytext.nicnamegenerator.namemerger.adapter;

import static android.content.Context.CLIPBOARD_SERVICE;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.BigNat;

import java.util.ArrayList;

public class FontAdapter extends RecyclerView.Adapter<FontAdapter.ViewHolder> {
    public Context activity;
    private ArrayList<String> dataList = new ArrayList<>();

    public FontAdapter(Context activity2) {
        this.activity = activity2;
    }

    public void setData(ArrayList<String> list) {
        this.dataList.clear();
        this.dataList.addAll( list );
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( activity ).inflate( R.layout.list_item_stylish_font, parent, false );
        return new ViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

/*
        if (position % 10 == 0) {
            holder.ad.setVisibility(View.VISIBLE);
            BigNat.getInstance((Activity) activity).showListNativeAds(holder.adLayout, holder.adText);
        } else {
            holder.ad.setVisibility(View.GONE);
        }

*/

        holder.description.setText( this.dataList.get( position ) );
        holder.description.setSelected( true );
        holder.number.setText( String.valueOf( position + 1 ) );

        final String text = holder.description.getText().toString();
        holder.copy.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService( CLIPBOARD_SERVICE );
                ClipData clip = ClipData.newPlainText( "", text );
                clipboard.setPrimaryClip( clip );
            }
        } );
        holder.share.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent( Intent.ACTION_SEND );
                i.setType( "text/plain" );
                i.putExtra( Intent.EXTRA_TEXT, text );
                activity.startActivity( i );
            }
        } );

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView copy;
        TextView description,adText;
        LinearLayout layout;
        TextView number;
        ImageView share;
        LinearLayout ad;
        FrameLayout adLayout;

        public ViewHolder(@NonNull View itemView) {
            super( itemView );
            this.description = (TextView) itemView.findViewById( R.id.descriptionTV );
            this.number = (TextView) itemView.findViewById( R.id.txt_number );
            this.copy = (ImageView) itemView.findViewById( R.id.btn_copy );
            this.share = (ImageView) itemView.findViewById( R.id.btn_share );
            this.layout = (LinearLayout) itemView.findViewById( R.id.linearclick );
 /*           this.ad=(LinearLayout) itemView.findViewById( R.id.ads );
            this.adText=(TextView) itemView.findViewById( R.id.ad_space );
            this.adLayout=(FrameLayout) itemView.findViewById( R.id.native_ad );*/
        }
    }
}
