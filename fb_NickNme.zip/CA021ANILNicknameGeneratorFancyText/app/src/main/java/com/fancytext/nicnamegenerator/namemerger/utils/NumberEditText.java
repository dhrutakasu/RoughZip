package com.fancytext.nicnamegenerator.namemerger.utils;

import android.text.Editable;
import android.text.TextWatcher;

import com.fancytext.nicnamegenerator.namemerger.ui.StylishNumberActivity;

public class NumberEditText implements TextWatcher {
    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        if (charSequence.length() == 0) {
            StylishNumberActivity.name_number = " ";
            StylishNumberActivity.numberAdapter.setName(StylishNumberActivity.name_number, StylishNumberActivity.type);
            StylishNumberActivity.numberAdapter.notifyDataSetChanged();
        } else if (charSequence.length() >= 1) {
            StylishNumberActivity.name_number = charSequence.toString();
            StylishNumberActivity.numberAdapter.setName(StylishNumberActivity.name_number, StylishNumberActivity.type);
        }
    }

    public void afterTextChanged(Editable editable) {
        StylishNumberActivity.name_number = "0123456789";
        StylishNumberActivity.numberAdapter.notifyDataSetChanged();
    }
}
