package com.fancytext.nicnamegenerator.namemerger.utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;


import com.fancytext.nicnamegenerator.namemerger.BuildConfig;
import com.fancytext.nicnamegenerator.namemerger.R;
import com.fancytext.nicnamegenerator.namemerger.admob.App;

public class VersionDialog {

    Dialog updateDialog;

    public VersionDialog(Context context, App applicationlist, OnUpdateListener listener) {
        updateDialog = new Dialog( context );
        updateDialog.setContentView( R.layout.dialog_update_app );
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom( updateDialog.getWindow().getAttributes() );
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;


        TextView updateBtn = updateDialog.findViewById( R.id.btn_update );
        TextView skipBtn = updateDialog.findViewById( R.id.btn_skip );

        updateBtn.setOnClickListener( v -> listener.onUpdate() );
        skipBtn.setOnClickListener( v -> {
            updateDialog.dismiss();
            listener.onSkip();
        } );

        updateDialog.getWindow().setAttributes( lp );
        updateDialog.getWindow().setBackgroundDrawable( new ColorDrawable( android.graphics.Color.TRANSPARENT ) );
        updateDialog.setCancelable( !applicationlist.is_force );

        if (applicationlist.is_force) skipBtn.setVisibility( View.GONE );
        else skipBtn.setVisibility( View.VISIBLE );

        if (applicationlist.version_code > BuildConfig.VERSION_CODE) {
            updateDialog.show();
        } else {
            listener.onSkip();
        }

        updateDialog.setOnDismissListener( dialog -> {
            listener.onSkip();
        } );

    }


    public interface OnUpdateListener {
        void onUpdate();

        void onSkip();
    }

}
