package com.fancytext.nicnamegenerator.namemerger.Interface;

public interface Style {
    String generate(String str);
}
