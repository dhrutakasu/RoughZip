package com.fancytext.nicnamegenerator.namemerger.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.fancytext.nicnamegenerator.namemerger.model.EmotiModel;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SharedPreference {
    public static final String FAVORITES = "Product_Favorite";
    public static final String PREFS_NAME = "PRODUCT_APP";

    public void saveFavorites(Context context, List<EmotiModel> favorites) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS_NAME, 0).edit();
        editor.putString(FAVORITES, new Gson().toJson((Object) favorites));
        editor.apply();
    }

    public void addFavorite(Context context, EmotiModel emotiModel) {
        List<EmotiModel> favorites = getFavorites(context);
        if (favorites == null) {
            favorites = new ArrayList<>();
        }
        favorites.add(emotiModel);
        saveFavorites(context, favorites);
    }

    public void removeFavorite(Context context, EmotiModel emotiModel) {
        ArrayList<EmotiModel> favorites = getFavorites(context);
        if (favorites != null) {
            favorites.remove(emotiModel);
            saveFavorites(context, favorites);
        }
    }

    public ArrayList<EmotiModel> getFavorites(Context context) {
        SharedPreferences settings = context.getSharedPreferences(PREFS_NAME, 0);
        if (!settings.contains(FAVORITES)) {
            return null;
        }
        return (ArrayList) new ArrayList<>(Arrays.asList((EmotiModel[]) new Gson().fromJson(settings.getString(FAVORITES, (String) null), EmotiModel[].class)));
    }
}
