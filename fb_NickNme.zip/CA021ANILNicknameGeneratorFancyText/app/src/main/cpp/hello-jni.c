#include <string.h>
#include <jni.h>



JNIEXPORT jstring JNICALL
Java_com_fancytext_nicnamegenerator_namemerger_admob_AllManager_BaseUrl(JNIEnv *env, jobject instance) {
return (*env)->NewStringUTF(env, "https://ads1727.codeairtech.com");
}


JNIEXPORT jstring JNICALL
Java_com_fancytext_nicnamegenerator_namemerger_admob_BackupBaseUrl(JNIEnv *env, jobject instance) {
    return (*env)->NewStringUTF(env, "https://codenateads.cyphernate.com");

}

JNIEXPORT jstring JNICALL
Java_com_fancytext_nicnamegenerator_namemerger_admob_AllManager_BackupBaseUrl(JNIEnv *env,
                                                                              jclass clazz) {
    return (*env)->NewStringUTF(env, "https://codenateads.cyphernate.com");
}